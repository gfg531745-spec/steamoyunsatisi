import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMutation } from "@tanstack/react-query";
import { useState } from "react";
import { Trash2, ShoppingCart, Loader2, BadgePercent, Check } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useCart, useGames } from "@/hooks/useCart";
import { useSession } from "@/hooks/useAuth";
import { useI18n } from "@/i18n";
import { placeGamesOrder, validateCoupon } from "@/lib/shop.functions";
import { BRAND, coverFor, formatPrice, waLink } from "@/lib/constants";

export const Route = createFileRoute("/cart")({
  head: () => ({
    meta: [
      { title: "Səbət — BakuSteamShop" },
      { name: "description", content: "Seçdiyiniz oyunları yoxlayın və sifarişi WhatsApp ilə göndərin." },
      { property: "og:title", content: "Səbət — BakuSteamShop" },
      { property: "og:description", content: "Seçdiyiniz oyunları yoxlayın və sifariş edin." },
    ],
  }),
  component: CartPage,
});

function CartPage() {
  const { t } = useI18n();
  const cart = useCart();
  const { data: games } = useGames();
  const { data: session } = useSession();
  const router = useRouter();
  const order = useServerFn(placeGamesOrder);
  const checkCoupon = useServerFn(validateCoupon);

  const [couponInput, setCouponInput] = useState("");
  const [coupon, setCoupon] = useState<{ code: string; percent: number } | null>(null);
  const [checking, setChecking] = useState(false);
  const [waUrl, setWaUrl] = useState<string | null>(null);
  // Open a window synchronously from the user's click to avoid popup blockers.
  let pendingWhatsAppWindow: Window | null = null;

  const items = (games ?? []).filter((g) => cart.ids.includes(g.id));
  const originalTotal = items.reduce((sum, g) => sum + Number(g.price), 0);
  const previewDiscount = coupon ? Math.round(originalTotal * coupon.percent) / 100 : 0;
  const previewTotal = Math.round((originalTotal - previewDiscount) * 100) / 100;

  async function applyCoupon() {
    const code = couponInput.trim();
    if (!code || coupon) return;
    setChecking(true);
    try {
      const res = await checkCoupon({ data: { code } });
      if (!res.valid) {
        toast.error(res.reason === "EXHAUSTED" ? t("cart.couponExhausted") : t("cart.couponInvalid"));
        return;
      }
      setCoupon({ code, percent: res.percent });
      toast.success(t("cart.couponApplied"));
    } catch {
      toast.error(t("common.error"));
    } finally {
      setChecking(false);
    }
  }

  const submit = useMutation({
    mutationFn: async () => {
      if (items.length === 0) throw new Error("EMPTY_CART");
      return order({ data: { couponCode: coupon?.code ?? null } });
    },
    onSuccess: (res) => {
      const lines = res.items
        .map((i) => `- ${i.title} x${i.quantity} — ${i.price.toFixed(2)} AZN`)
        .join("\n");
      const text = [
        `New ${BRAND} Order`,
        "",
        `Customer: ${res.customerName ?? "-"}`,
        `Email: ${res.customerEmail ?? session?.user.email ?? "-"}`,
        "",
        "Products:",
        lines,
        "",
        `Coupon: ${res.couponCode ?? "None"}`,
        `Discount: ${res.percent > 0 ? `${res.percent}% (${res.discount.toFixed(2)} AZN)` : "0"}`,
        `Original total: ${res.originalTotal.toFixed(2)} AZN`,
        `Final total: ${res.total.toFixed(2)} AZN`,
        `Order ID: ${res.orderId}`,
      ].join("\n");

      cart.clearLocal();
      setCoupon(null);
      setCouponInput("");
      toast.success(t("cart.sent"));

      const url = waLink(text);
      if (pendingWhatsAppWindow && !pendingWhatsAppWindow.closed) {
        pendingWhatsAppWindow.location.href = url;
        pendingWhatsAppWindow = null;
        void router.navigate({ to: "/orders" });
        return;
      }

      // Fallback when the browser blocked the pre-opened tab. Keep the order
      // intact and give the customer an explicit WhatsApp button.
      setWaUrl(url);
      toast.info(t("cart.openWhatsapp"), {
        action: { label: t("cart.openWhatsapp"), onClick: () => window.open(url, "_blank") },
      });
    },

    onError: (err) => {
      if (pendingWhatsAppWindow && !pendingWhatsAppWindow.closed) {
        pendingWhatsAppWindow.close();
        pendingWhatsAppWindow = null;
      }
      const code = err instanceof Error ? err.message : "";
      if (code.includes("EMPTY_CART")) toast.error(t("cart.emptyError"));
      else if (code.includes("COUPON_EXHAUSTED")) {
        setCoupon(null);
        toast.error(t("cart.couponExhausted"));
      } else if (code.includes("COUPON_INVALID")) {
        setCoupon(null);
        toast.error(t("cart.couponInvalid"));
      } else toast.error(t("cart.orderFailed"));
    },
  });

  return (
    <div className="mx-auto w-full max-w-5xl px-4 py-10">
      <h1 className="font-display text-3xl font-bold">{t("cart.title")}</h1>
      <p className="mt-1 text-sm text-muted-foreground">{t("cart.hint")}</p>

      {waUrl ? (
        <div className="mt-6 flex flex-col items-start gap-3 rounded-xl border border-primary/40 bg-primary/10 p-4 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-sm font-medium">{t("cart.sent")}</p>
          <Button asChild className="shadow-gold">
            <a href={waUrl} target="_blank" rel="noopener noreferrer">
              {t("cart.openWhatsapp")}
            </a>
          </Button>
        </div>
      ) : null}

      {items.length === 0 ? (
        <div className="mt-14 flex flex-col items-center gap-4 text-center">
          <ShoppingCart className="size-12 text-muted-foreground" />
          <p className="text-muted-foreground">{t("cart.empty")}</p>
          <Button asChild>
            <Link to="/">{t("home.browse")}</Link>
          </Button>
        </div>
      ) : (
        <div className="mt-8 grid gap-6 lg:grid-cols-[1fr_320px]">
          <ul className="space-y-3">
            {items.map((g) => (
              <li
                key={g.id}
                className="flex animate-fade-up items-center gap-4 rounded-xl border border-border/70 bg-card p-3 card-elevated"
              >
                <img
                  src={coverFor(g)}
                  alt={g.title}
                  className="h-20 w-14 shrink-0 rounded-md object-cover"
                />
                <div className="min-w-0 flex-1">
                  <p className="truncate font-semibold">{g.title}</p>
                  <p className="text-sm text-primary">{formatPrice(Number(g.price))}</p>
                </div>
                <Button variant="ghost" size="icon" onClick={() => cart.remove(g.id)}>
                  <Trash2 className="size-4 text-destructive" />
                </Button>
              </li>
            ))}
          </ul>

          <aside className="h-fit rounded-2xl border border-border/70 bg-card p-5 card-elevated lg:sticky lg:top-24">
            {session ? (
              <div className="mb-4 space-y-2">
                {coupon ? (
                  <div className="flex items-center justify-between rounded-lg border border-primary/40 bg-primary/10 px-3 py-2 text-sm">
                    <span className="flex items-center gap-2 font-semibold text-primary">
                      <Check className="size-4" />
                      {coupon.code} · {coupon.percent}%
                    </span>
                    <button
                      type="button"
                      className="text-xs text-muted-foreground hover:text-destructive"
                      onClick={() => {
                        setCoupon(null);
                        setCouponInput("");
                      }}
                    >
                      {t("cart.removeCoupon")}
                    </button>
                  </div>
                ) : (
                  <div className="flex gap-2">
                    <Input
                      value={couponInput}
                      maxLength={40}
                      placeholder={t("cart.coupon")}
                      onChange={(e) => setCouponInput(e.target.value)}
                    />
                    <Button variant="secondary" onClick={applyCoupon} disabled={checking}>
                      {checking ? (
                        <Loader2 className="size-4 animate-spin" />
                      ) : (
                        <BadgePercent className="size-4" />
                      )}
                      {t("cart.applyCoupon")}
                    </Button>
                  </div>
                )}
              </div>
            ) : null}

            <div className="space-y-1.5 text-sm text-muted-foreground">
              <div className="flex items-center justify-between">
                <span>{coupon ? t("cart.original") : t("cart.total")}</span>
                <span className={coupon ? "line-through" : "font-display text-xl font-bold text-primary"}>
                  {formatPrice(originalTotal)}
                </span>
              </div>
              {coupon ? (
                <>
                  <div className="flex items-center justify-between text-accent">
                    <span>{t("cart.discount")}</span>
                    <span>-{formatPrice(previewDiscount)}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>{t("cart.final")}</span>
                    <span className="font-display text-2xl font-bold text-primary">
                      {formatPrice(previewTotal)}
                    </span>
                  </div>
                </>
              ) : null}
            </div>

            {session ? (
              <Button
                className="mt-5 w-full shadow-gold"
                size="lg"
                disabled={submit.isPending}
                onClick={() => {
                  pendingWhatsAppWindow = window.open("about:blank", "_blank", "noopener,noreferrer");
                  submit.mutate();
                }}
              >
                {submit.isPending ? <Loader2 className="size-4 animate-spin" /> : null}
                {t("cart.order")}
              </Button>
            ) : (
              <Button asChild className="mt-5 w-full" size="lg">
                <Link to="/auth">{t("game.loginToBuy")}</Link>
              </Button>
            )}
          </aside>
        </div>
      )}
    </div>
  );
}
