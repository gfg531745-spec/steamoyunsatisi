# Baku Game Hub

sell games for computer and I want a sales website for it. The company name is BakuSteamShop. Let there be a cart, but when an order is placed, it should automatically go to the conversation with 0555842012 and send the order. The website should be both mobile and PC compatible. Graphically, make it very good, from Rockstar only let there be GTA 5, and let every game's image be on its own cover. The name should be written below, game list:

Ghost of Tsushima DIRECTOR'S CUT FIVE NIGHTS AT FREDDY'S: HELP WANTED Mortal Kombat 11 City Car Driving DARK SOULS II: Scholar of the First Sin METAL GEAR SOLID 3 Δ: SNAKE EATER + Digital Deluxe Edition Please, Don't Touch Anything 3D Poppy Playtime + Chapter 1-2-3-4-5 Raft FC 25 Counter-Strike 1.6 Party Panic Lies of P + Overture DLC CRISIS CORE –FINAL FANTASY VII– REUNION Only Up! Cyberpunk 2077 Mafia: The Old Country + Deluxe Edition UNCHARTED: Legacy of Thieves Collection Grand Theft Auto V Legacy Grand Theft Auto V Enhanced Max Payne 1 ARK: Survival Evolved Resident Evil 4 Remake Black Myth: Wukong Counter-Strike: Condition Zero Kindergarten Football Life Simulator Mafia: Definitive Edition Sekiro: Shadows Die Twice WWE 2K19 SUPERHOT Red Dead Redemption 2 Marvel’s Spider-Man Remastered Grand Theft Auto: San Andreas FIFA 23 + Ultimate Edition Five Nights at Freddy's: Security Breach Internet Cafe Simulator 2 SILENT HILL F - Digital Deluxe Edition Lossless Scaling Left 4 Dead Escape the Backrooms Pro Evolution Soccer 2014 Supermarket Simulator Plague Inc: Evolved Plants vs. Zombies: Game of the Year Hello Neighbor Mafia II: Definitive Edition Dispatch + Digital Deluxe Edition Grand Theft Auto: San Andreas - The Definitive Edition Wallpaper Engine Call of Duty: Modern Warfare 3 (2011) The Last of Us Part II Remastered SUPERHOT: MIND CONTROL DELETE God of War FC 24 Five Nights at Freddy's 4 Outlast ELDEN RING + Shadow of the Erdtree DLC Forza Horizon 5 Goat Simulator 3 Grand Theft Auto: Vice City FreshWomen - Season 1 Grand Theft Auto IV: The Complete Edition Nioh 3 + Digital Deluxe Edition FIFA 22 + Ultimate Edition A Plague Tale: Requiem Cyberpunk 2077 DOOM: The Dark Ages Clair Obscur: Expedition 33 + Deluxe Edition Euro Truck Simulator 2 Garry's Mod The Amazing Spider-Man 2 Resident Evil 7 Biohazard Kindergarten 2 Call of Duty 4: Modern Warfare (2007) Counter-Strike: Condition Zero Deleted Scenes Mount & Blade II Bannerlord Left 4 Dead 2 Red Dead Redemption 1 METAL GEAR SOLID V: THE PHANTOM PAIN eFootball PES 2021 SEASON UPDATE Max Payne 2 DARK SOULS: REMASTERED ELDEN RING + DELUXE EDITION Half-Life Call of Duty: Modern Warfare 2 (2009) Pacify Five Nights at Freddy's: Into the Pit God of War Ragnarök FC 26 - EA Hesabı Streamer Life Simulator 2 Five Nights at Freddy's: Help Wanted 2 DARK SOULS III Forza Horizon 4 The Witcher 3: Wild Hunt FC 26 + Ultimate Edition + Türkçe Spiker

Let there be an admin panel, add these games in the admin, but when a new game comes, the admin should also be able to add it. Let there be 4 languages: Azerbaijani, Russian, Turkish, English. The admin should be only the person who creates an account with gfg531745@gmail.com. Let there be account creation, registration, login, etc. The admin should also be able to adjust game prices. Every game should be 4 AZN.

After someone adds something to the cart, I should receive a message, but when they enter again later, that order should still remain. If they want to buy something else, they should have to manually delete the previous one. The cart should be saved, and even after exiting and entering again, it should remain, but after pressing the order button, the cart should be reset.

And let there be an account system so every person can login, sign up and create an account, and can enter an existing account. It should be protected from attacks that may happen. If more than 20 devices log in from 1 IP address at the same time, that IP should be blocked from logging in for 1 hour.

And let there be admins, and from the users who enter the website, I should be able to select admins.

And when entering the website, it should first give this information:

"Accounts are shared. Each game is on a separate account, and 90% of the accounts also have other games on them as a gift."

Also, there should be a language selection on the website: Turkish, Azerbaijani, Russian, English. In Azerbaijani, every word should be in Azerbaijani; in Turkish, in Turkish; in English, in English; in Russian, in Russian. But no matter which language is selected, the currency should remain the same, manat.

After an admin confirms an order, that order should give the account XP. Every level should have a certain amount of XP, and the user should level up. At levels 3, 5, 10, 15, 20, and 25, the user should receive 1 additional game as a gift.

Also increase the animations on the website.

The website should have Google sign up and login, and "I forgot my password". When creating a new account, a verification code should be sent to the email.
There should be 4 languages. The main language should be Azerbaijani, and it should be possible to change the language by selecting a language.

The languages should be:
Azerbaijani, English, Russian, Turkish.

And there should be an additional tab called "My Games".

In the admin panel, the admin should add the password and email of each game account.

When the admin confirms an order, the game should appear in the user's "My Games" tab.

When the user is in "My Games", they should be able to view the account password.

When viewing the account password, there should also be another button called "Get OTP Code".

When pressing it, it should redirect the user to my chat and automatically send a message asking for the OTP code for whichever game it is.

And there should be another tab for normal users called "Special Packages".

In the admin panel, it should be possible to add packages to that tab.

For example, a package could be 3 games for 10 AZN.

When a person buys a package, for example, a 3-game package for 10 AZN, and the admin confirms it, the user should be able to select 3 free games from the website.

The games selected by the user should no longer need to be individually confirmed by the admin and should automatically be added to "My Games".

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/ea26f336-4624-4b06-996d-ee05aba317c2).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
