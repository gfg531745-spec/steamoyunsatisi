import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/hooks/useAuth";

const KEY = "bsa-cart";

function readLocal(): string[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(KEY);
    const parsed = raw ? (JSON.parse(raw) as unknown) : [];
    return Array.isArray(parsed) ? (parsed as string[]) : [];
  } catch {
    return [];
  }
}

function writeLocal(ids: string[]) {
  window.localStorage.setItem(KEY, JSON.stringify(ids));
}

export function useCart() {
  const queryClient = useQueryClient();
  const { data: session } = useSession();
  const userId = session?.user.id ?? null;

  const cart = useQuery({
    queryKey: ["cart", userId],
    queryFn: async (): Promise<string[]> => {
      if (!userId) return readLocal();
      const { data, error } = await supabase
        .from("cart_items")
        .select("game_id")
        .eq("user_id", userId);
      if (error) throw error;
      return (data ?? []).map((r) => r.game_id);
    },
  });

  // Merge a guest cart into the account cart right after sign-in.
  useEffect(() => {
    if (!userId) return;
    const local = readLocal();
    if (local.length === 0) return;
    void (async () => {
      await supabase
        .from("cart_items")
        .upsert(
          local.map((game_id) => ({ user_id: userId, game_id })),
          { onConflict: "user_id,game_id" },
        );
      writeLocal([]);
      queryClient.invalidateQueries({ queryKey: ["cart", userId] });
    })();
  }, [userId, queryClient]);

  const add = useMutation({
    mutationFn: async (gameId: string) => {
      if (!userId) {
        const next = Array.from(new Set([...readLocal(), gameId]));
        writeLocal(next);
        return;
      }
      const { error } = await supabase
        .from("cart_items")
        .upsert({ user_id: userId, game_id: gameId }, { onConflict: "user_id,game_id" });
      if (error) throw error;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["cart", userId] }),
  });

  const remove = useMutation({
    mutationFn: async (gameId: string) => {
      if (!userId) {
        writeLocal(readLocal().filter((id) => id !== gameId));
        return;
      }
      const { error } = await supabase
        .from("cart_items")
        .delete()
        .eq("user_id", userId)
        .eq("game_id", gameId);
      if (error) throw error;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["cart", userId] }),
  });

  const ids = cart.data ?? [];

  return {
    ids,
    count: ids.length,
    isLoading: cart.isLoading,
    has: (id: string) => ids.includes(id),
    add: (id: string) => add.mutate(id),
    remove: (id: string) => remove.mutate(id),
    clearLocal: () => {
      writeLocal([]);
      queryClient.invalidateQueries({ queryKey: ["cart", userId] });
    },
  };
}

export function useGames() {
  return useQuery({
    queryKey: ["games"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("games")
        .select("id, title, slug, cover_url, steam_appid, price, active, sort_order")
        .eq("active", true)
        .order("sort_order", { ascending: true });
      if (error) throw error;
      return data ?? [];
    },
  });
}

export type Game = NonNullable<ReturnType<typeof useGames>["data"]>[number];
