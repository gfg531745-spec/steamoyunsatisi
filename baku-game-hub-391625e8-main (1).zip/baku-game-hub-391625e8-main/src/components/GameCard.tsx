import { Check, ExternalLink, Plus, ShoppingCart } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { coverFor, formatPrice } from "@/lib/constants";
import { useI18n } from "@/i18n";
import { cn } from "@/lib/utils";

export type GameCardGame = {
  id: string;
  title: string;
  cover_url: string | null;
  steam_appid: number | null;
  price: number | string;
};

export function GameCard({
  game,
  inCart,
  owned,
  onAdd,
  index = 0,
}: {
  game: GameCardGame;
  inCart?: boolean | undefined;
  owned?: boolean | undefined;
  onAdd?: (() => void) | undefined;
  index?: number | undefined;
}) {
  const { t } = useI18n();
  const [failed, setFailed] = useState(false);
  const cover = coverFor(game);
  const fallback =
    game.steam_appid && failed
      ? `https://cdn.cloudflare.steamstatic.com/steam/apps/${game.steam_appid}/header.jpg`
      : null;
  const src = failed ? fallback : cover;

  const steamUrl = game.steam_appid ? `https://store.steampowered.com/app/${game.steam_appid}/` : null;

  return (
    <article
      className="group relative animate-fade-up overflow-hidden rounded-2xl border border-border/70 bg-card card-elevated transition-all duration-300 hover:-translate-y-2 hover:border-accent/60 hover:shadow-neon"
      style={{ animationDelay: `${Math.min(index, 14) * 35}ms` }}
    >
      <div className="pointer-events-none absolute inset-0 z-10 rounded-2xl opacity-0 transition-opacity duration-300 group-hover:opacity-100 [background:linear-gradient(130deg,transparent_35%,oklch(0.95_0.05_200/0.12)_50%,transparent_65%)]" />
      <a
        href={steamUrl ?? undefined}
        target="_blank"
        rel="noreferrer"
        aria-label={`${game.title} — Steam`}
        className="relative block aspect-[2/3] overflow-hidden bg-secondary"
      >
        {src ? (
          <img
            src={src}
            alt={`${game.title} cover`}
            loading="lazy"
            onError={() => setFailed(true)}
            className="size-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.08]"
          />
        ) : (
          <div className="flex size-full items-center justify-center p-4 text-center text-sm text-muted-foreground">
            {game.title}
          </div>
        )}
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-background via-background/15 to-transparent" />
        {steamUrl ? (
          <span className="pointer-events-none absolute inset-x-0 bottom-0 flex translate-y-3 items-center justify-center gap-1.5 pb-3 text-xs font-semibold text-accent opacity-0 transition-all duration-300 group-hover:translate-y-0 group-hover:opacity-100">
            <ExternalLink className="size-3.5" />
            Steam
          </span>
        ) : null}
        <span className="absolute left-2 top-2 rounded-full border border-primary/40 bg-background/80 px-2.5 py-1 text-xs font-semibold text-primary backdrop-blur">
          {formatPrice(Number(game.price))}
        </span>
        {owned ? (
          <span className="absolute right-2 top-2 rounded-full bg-success px-2.5 py-1 text-xs font-semibold text-success-foreground">
            {t("game.owned")}
          </span>
        ) : null}
      </a>


      <div className="space-y-3 p-3">
        <h3 className="line-clamp-2 min-h-10 text-sm font-semibold leading-snug">{game.title}</h3>
        {!owned && onAdd ? (
          <Button
            size="sm"
            variant={inCart ? "secondary" : "default"}
            onClick={onAdd}
            disabled={inCart}
            className={cn("w-full gap-2 text-xs font-semibold", !inCart && "shadow-gold")}
          >
            {inCart ? <Check className="size-4" /> : <Plus className="size-4" />}
            {inCart ? t("game.inCart") : t("game.add")}
          </Button>
        ) : null}
        {owned ? (
          <div className="flex items-center justify-center gap-2 rounded-md bg-secondary py-2 text-xs font-medium text-muted-foreground">
            <ShoppingCart className="size-3.5" />
            {t("game.owned")}
          </div>
        ) : null}
      </div>
    </article>
  );
}
