import { Link, useRouter } from "@tanstack/react-router";
import {
  Gamepad2,
  LogIn,
  LogOut,
  Menu,
  Package,
  ShieldCheck,
  ShoppingCart,
  Sparkles,
  ReceiptText,
} from "lucide-react";
import { useState, type ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { LanguageSwitcher } from "@/components/LanguageSwitcher";
import { useIsAdmin, useSession } from "@/hooks/useAuth";
import { AuthTransition } from "@/components/AuthTransition";
import { useCart } from "@/hooks/useCart";
import { useI18n } from "@/i18n";
import { BRAND, WHATSAPP_NUMBER } from "@/lib/constants";
import { supabase } from "@/integrations/supabase/client";

const LOGO_SRC = "/bakusteamshop-logo.png";

function NavLinks({ onNavigate }: { onNavigate?: () => void }) {
  const { t } = useI18n();
  const { data: session } = useSession();
  const { data: isAdmin } = useIsAdmin();

  const items = [
    { to: "/", label: t("nav.games"), icon: Gamepad2 },
    { to: "/packages", label: t("nav.packages"), icon: Sparkles },
    ...(session
      ? [
          { to: "/my-games", label: t("nav.myGames"), icon: Package },
          { to: "/orders", label: t("nav.orders"), icon: ReceiptText },
        ]
      : []),
    ...(isAdmin ? [{ to: "/admin", label: t("nav.admin"), icon: ShieldCheck }] : []),
  ] as const;

  return (
    <>
      {items.map((item) => (
        <Link
          key={item.to}
          to={item.to}
          onClick={onNavigate}
          activeProps={{
            className:
              "border-primary/50 bg-primary/15 text-primary shadow-gold [&_svg]:text-primary",
          }}
          className="group flex shrink-0 items-center gap-2 whitespace-nowrap rounded-xl border border-border/60 bg-card/50 px-3.5 py-2 text-sm font-semibold text-muted-foreground backdrop-blur transition-all duration-200 hover:-translate-y-0.5 hover:border-accent/50 hover:bg-accent/10 hover:text-foreground active:translate-y-0"
        >
          <item.icon className="size-4 text-muted-foreground transition-colors group-hover:text-accent" />
          {item.label}
        </Link>
      ))}
    </>
  );
}

export function SiteLayout({ children }: { children: ReactNode }) {
  const { t } = useI18n();
  const { data: session } = useSession();
  const { count } = useCart();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [signingOut, setSigningOut] = useState(false);

  async function signOut() {
    setSigningOut(true);
    try {
      await supabase.auth.signOut();
    } finally {
      // Never let the animation hold the user hostage.
      window.setTimeout(() => {
        void router.navigate({ to: "/", replace: true });
        setSigningOut(false);
      }, 650);
    }
  }

  return (
    <div className="flex min-h-screen flex-col">
      {signingOut ? <AuthTransition mode="out" label={t("auth.bye")} /> : null}
      <header className="sticky top-0 z-50 border-b border-border/60 bg-background/85 backdrop-blur-xl">
        <div className="mx-auto flex h-16 w-full max-w-7xl items-center gap-3 px-4">
          <Link to="/" className="flex items-center gap-2">
            <img
              src={LOGO_SRC}
              alt="BakuSteamShop loqosu"
              className="size-11 shrink-0 rounded-full border border-border bg-card object-cover shadow-gold"
            />
            <span className="font-display text-sm font-bold leading-tight sm:text-base">
              <span className="text-gold">Baku</span>SteamShop
            </span>
          </Link>

          <nav className="ml-4 hidden items-center gap-1 md:flex">
            <NavLinks />
          </nav>

          <div className="ml-auto flex items-center gap-1.5">
            <LanguageSwitcher />

            <Button asChild variant="ghost" size="sm" className="relative gap-2">
              <Link to="/cart">
                <ShoppingCart className="size-4" />
                <span className="hidden sm:inline">{t("nav.cart")}</span>
                {count > 0 ? (
                  <span className="absolute -right-0.5 -top-0.5 grid size-5 animate-pop place-items-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground">
                    {count}
                  </span>
                ) : null}
              </Link>
            </Button>

            {session ? (
              <Button variant="ghost" size="sm" onClick={signOut} className="gap-2">
                <LogOut className="size-4" />
                <span className="hidden md:inline">{t("nav.logout")}</span>
              </Button>
            ) : (
              <Button asChild size="sm" className="gap-2 shadow-gold">
                <Link to="/auth">
                  <LogIn className="size-4" />
                  <span className="hidden sm:inline">{t("nav.login")}</span>
                </Link>
              </Button>
            )}

            <Sheet open={open} onOpenChange={setOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="size-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-72 p-4">
                <div className="mt-8 flex flex-col gap-1">
                  <NavLinks onNavigate={() => setOpen(false)} />
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>

        <nav className="flex w-full items-center gap-1 overflow-x-auto border-t border-border/60 px-2 py-1.5 md:hidden [&::-webkit-scrollbar]:hidden">
          <NavLinks />
        </nav>
      </header>

      <main className="flex-1">{children}</main>

      <footer className="border-t border-border/60 bg-card/40">
        <div className="mx-auto flex w-full max-w-7xl flex-col gap-2 px-4 py-8 text-sm text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
          <p className="font-display text-foreground">{BRAND}</p>
          <p>
            WhatsApp:{" "}
            <a
              className="text-accent hover:underline"
              href={`https://wa.me/${WHATSAPP_NUMBER}`}
              target="_blank"
              rel="noreferrer"
            >
              +994 55 584 20 12
            </a>
          </p>
          <p>
            © {new Date().getFullYear()} {BRAND}. {t("footer.rights")}
          </p>
        </div>
      </footer>
    </div>
  );
}
