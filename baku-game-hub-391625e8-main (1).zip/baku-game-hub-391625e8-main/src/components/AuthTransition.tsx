import { Gamepad2, LogOut } from "lucide-react";

/**
 * Short, subtle full-screen transition shown right after a successful
 * sign-in or sign-out. Purely visual — it never blocks the auth call itself.
 * Motion is disabled automatically via `motion-reduce` utilities.
 */
export function AuthTransition({ mode, label }: { mode: "in" | "out"; label: string }) {
  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed inset-0 z-[100] grid place-items-center bg-background/95 backdrop-blur-xl animate-fade-in motion-reduce:animate-none"
    >
      <div
        className={`flex flex-col items-center gap-4 ${
          mode === "in" ? "animate-auth-in" : "animate-auth-out"
        } motion-reduce:animate-none`}
      >
        <span className="grid size-16 place-items-center rounded-2xl bg-primary text-primary-foreground shadow-gold">
          {mode === "in" ? <Gamepad2 className="size-7" /> : <LogOut className="size-7" />}
        </span>
        <p className="font-display text-lg font-semibold">{label}</p>
      </div>
    </div>
  );
}
