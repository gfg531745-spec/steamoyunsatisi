import { useEffect, useState } from "react";
import { Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { useI18n } from "@/i18n";

const KEY = "bsa-notice-seen";

export function NoticeDialog() {
  const { t } = useI18n();
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!window.localStorage.getItem(KEY)) setOpen(true);
  }, []);

  function close() {
    window.localStorage.setItem(KEY, "1");
    setOpen(false);
  }

  return (
    <Dialog open={open} onOpenChange={(v) => (v ? setOpen(true) : close())}>
      <DialogContent className="max-w-md border-accent/40 shadow-neon">
        <div className="grid size-11 place-items-center rounded-xl bg-accent/15 text-accent">
          <Info className="size-5" />
        </div>
        <DialogTitle className="font-display text-lg">{t("notice.title")}</DialogTitle>
        <DialogDescription className="text-sm leading-relaxed text-muted-foreground">
          {t("notice.text")}
        </DialogDescription>
        <Button onClick={close} className="w-full shadow-gold">
          {t("notice.ok")}
        </Button>
      </DialogContent>
    </Dialog>
  );
}
