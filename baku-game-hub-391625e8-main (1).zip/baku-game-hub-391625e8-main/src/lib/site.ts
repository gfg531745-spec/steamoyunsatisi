/** Canonical production origin used for auth email redirects. */
export const PRODUCTION_ORIGIN = "https://bakusteam.shop";

/**
 * Origin to use for Supabase auth redirect links.
 * Local/preview keeps its own origin so testing works; anything else
 * (GitHub -> Cloudflare deployment) always uses the production domain.
 */
export function authRedirectOrigin() {
  if (typeof window === "undefined") return PRODUCTION_ORIGIN;
  const host = window.location.hostname;
  const isLocal =
    host === "localhost" ||
    host === "127.0.0.1" ||
    host.endsWith(".lovable.app") ||
    host.endsWith(".lovableproject.com");
  return isLocal ? window.location.origin : PRODUCTION_ORIGIN;
}
