export const BRAND = "BakuSteamShop";

/** WhatsApp contact for orders and OTP requests (0555842012 -> international) */
export const WHATSAPP_NUMBER = "994555842012";

export const CURRENCY = "AZN";

export const XP_PER_GAME = 100;
export const XP_PER_LEVEL = 300;

/** Levels that award one extra free game. */
export const GIFT_LEVELS = [3, 5, 10, 15, 20, 25];

export function levelFromXp(xp: number): number {
  return Math.floor(xp / XP_PER_LEVEL) + 1;
}

export function levelProgress(xp: number) {
  const level = levelFromXp(xp);
  const inLevel = xp - (level - 1) * XP_PER_LEVEL;
  return {
    level,
    inLevel,
    needed: XP_PER_LEVEL,
    percent: Math.min(100, Math.round((inLevel / XP_PER_LEVEL) * 100)),
  };
}

export function coverFor(game: { cover_url?: string | null; steam_appid?: number | null }) {
  if (game.cover_url) return game.cover_url;
  if (game.steam_appid)
    return `https://cdn.cloudflare.steamstatic.com/steam/apps/${game.steam_appid}/library_600x900.jpg`;
  return "";
}

export function waLink(text: string) {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`;
}

export function formatPrice(value: number | string) {
  const n = typeof value === "string" ? Number(value) : value;
  return `${n.toFixed(2)} ₼`;
}
