import { createServerFn } from "@tanstack/react-start";
import { getRequestHeader } from "@tanstack/react-start/server";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/** Normalize a user-typed coupon code (handles Turkish/Azerbaijani dotted letters). */
export function normalizeCoupon(code: string) {
  return code
    .trim()
    .toUpperCase()
    .normalize("NFD")
    .replace(/[^A-Z0-9]/g, "");
}

/** Read-only coupon check for the cart UI. Never applies a discount by itself. */
export const validateCoupon = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { code: string }) => data)
  .handler(async ({ data }) => {
    const code = normalizeCoupon(String(data.code ?? "").slice(0, 40));
    if (!code) return { valid: false as const, reason: "INVALID" as const };

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: coupon } = await supabaseAdmin
      .from("coupons")
      .select("code, percent, max_uses, used_count, active")
      .eq("code", code)
      .eq("active", true)
      .maybeSingle();

    if (!coupon) return { valid: false as const, reason: "INVALID" as const };
    if (coupon.used_count >= coupon.max_uses)
      return { valid: false as const, reason: "EXHAUSTED" as const };
    return { valid: true as const, percent: coupon.percent as number };
  });

/** Create a pending order from the user's saved cart and clear the cart. */
export const placeGamesOrder = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { couponCode?: string | null } | undefined) => data ?? {})
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;

    const { data: cart, error: cartError } = await supabase
      .from("cart_items")
      .select("game_id, games ( id, title, price )")
      .eq("user_id", userId);
    if (cartError) throw new Error(cartError.message);
    if (!cart || cart.length === 0) throw new Error("EMPTY_CART");

    const items = cart
      .map((row) => row.games as unknown as { id: string; title: string; price: number } | null)
      .filter((g): g is { id: string; title: string; price: number } => Boolean(g));

    const originalTotal = Math.round(items.reduce((sum, g) => sum + Number(g.price), 0) * 100) / 100;

    // Coupon: the discount is decided and consumed on the server only.
    const requested = normalizeCoupon(String(data?.couponCode ?? "").slice(0, 40));
    let percent = 0;
    let claimedCode: string | null = null;

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    if (requested) {
      const { data: coupon } = await supabaseAdmin
        .from("coupons")
        .select("code, active")
        .eq("code", requested)
        .eq("active", true)
        .maybeSingle();
      if (!coupon) throw new Error("COUPON_INVALID");

      // Atomic slot claim: only succeeds while used_count < max_uses.
      const { data: claimedPercent, error: claimError } = await supabaseAdmin.rpc(
        "consume_coupon",
        { _code: requested },
      );
      if (claimError) throw new Error("ORDER_FAILED");
      if (claimedPercent === null || claimedPercent === undefined)
        throw new Error("COUPON_EXHAUSTED");
      percent = Number(claimedPercent);
      claimedCode = requested;
    }

    const releaseClaim = async () => {
      if (claimedCode) await supabaseAdmin.rpc("release_coupon", { _code: claimedCode });
    };

    const discount = Math.round(originalTotal * percent) / 100;
    const total = Math.round((originalTotal - discount) * 100) / 100;

    const { data: order, error: orderError } = await supabase
      .from("orders")
      .insert({
        user_id: userId,
        status: "pending",
        kind: "games",
        total,
        original_total: originalTotal,
        discount,
        coupon_code: claimedCode,
      })
      .select("id, created_at")
      .single();
    if (orderError || !order) {
      await releaseClaim();
      throw new Error("ORDER_FAILED");
    }

    const { error: itemsError } = await supabase.from("order_items").insert(
      items.map((g) => ({
        order_id: order.id,
        game_id: g.id,
        title: g.title,
        price: Number(g.price),
      })),
    );
    if (itemsError) {
      await supabaseAdmin.from("orders").delete().eq("id", order.id);
      await releaseClaim();
      throw new Error("ORDER_FAILED");
    }

    const { error: clearError } = await supabase
      .from("cart_items")
      .delete()
      .eq("user_id", userId);
    if (clearError) throw new Error("ORDER_FAILED");

    const { data: profile } = await supabase
      .from("profiles")
      .select("email, display_name")
      .eq("id", userId)
      .maybeSingle();

    return {
      orderId: order.id as string,
      total,
      originalTotal,
      discount,
      couponCode: claimedCode ? "CONGRULAT\u0130ONS" : null,
      percent,
      customerName: profile?.display_name ?? null,
      customerEmail: profile?.email ?? null,
      items: items.map((g) => ({ title: g.title, price: Number(g.price), quantity: 1 })),
    };
  });

/** Create a pending order for a special package. */
export const placePackageOrder = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { packageId: string }) => data)
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;

    const { data: pkg, error: pkgError } = await supabase
      .from("packages")
      .select("id, title, price, games_count")
      .eq("id", data.packageId)
      .eq("active", true)
      .single();
    if (pkgError || !pkg) throw new Error("PACKAGE_NOT_FOUND");

    const { data: order, error: orderError } = await supabase
      .from("orders")
      .insert({
        user_id: userId,
        status: "pending",
        kind: "package",
        package_id: pkg.id,
        total: Number(pkg.price),
      })
      .select("id")
      .single();
    if (orderError || !order) throw new Error(orderError?.message ?? "ORDER_FAILED");

    const { error: itemError } = await supabase.from("order_items").insert({
      order_id: order.id,
      title: `${pkg.title} (${pkg.games_count})`,
      price: Number(pkg.price),
    });
    if (itemError) throw new Error(itemError.message);

    return {
      orderId: order.id as string,
      title: pkg.title as string,
      gamesCount: pkg.games_count as number,
      total: Number(pkg.price),
    };
  });

/** Account credentials for a game the caller actually owns. */
export const getOwnedCredentials = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { gameId: string }) => data)
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;

    const { data: owned } = await supabase
      .from("user_games")
      .select("id")
      .eq("user_id", userId)
      .eq("game_id", data.gameId)
      .maybeSingle();
    if (!owned) throw new Error("NOT_OWNED");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: creds } = await supabaseAdmin
      .from("game_credentials")
      .select("account_email, account_password, note")
      .eq("game_id", data.gameId)
      .maybeSingle();

    return {
      email: creds?.account_email ?? null,
      password: creds?.account_password ?? null,
      note: creds?.note ?? null,
    };
  });

/** Spend one free-game credit on a chosen game. */
export const claimFreeGame = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { gameId: string }) => data)
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;

    const { data: profile } = await supabase
      .from("profiles")
      .select("gift_credits")
      .eq("id", userId)
      .single();
    if (!profile || profile.gift_credits < 1) throw new Error("NO_CREDITS");

    const { data: already } = await supabase
      .from("user_games")
      .select("id")
      .eq("user_id", userId)
      .eq("game_id", data.gameId)
      .maybeSingle();
    if (already) throw new Error("ALREADY_OWNED");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error: insertError } = await supabaseAdmin
      .from("user_games")
      .insert({ user_id: userId, game_id: data.gameId, source: "gift" });
    if (insertError) throw new Error(insertError.message);

    const { error: updateError } = await supabaseAdmin
      .from("profiles")
      .update({ gift_credits: profile.gift_credits - 1 })
      .eq("id", userId);
    if (updateError) throw new Error(updateError.message);

    return { ok: true as const, remaining: profile.gift_credits - 1 };
  });

/** Admin: confirm an order, deliver games, grant XP, levels and milestone gifts. */
export const adminReviewOrder = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { orderId: string; approve: boolean }) => data)
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;

    const { data: isAdmin } = await supabase.rpc("has_role", {
      _user_id: userId,
      _role: "admin",
    });
    if (!isAdmin) throw new Error("FORBIDDEN");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: order } = await supabaseAdmin
      .from("orders")
      .select("id, user_id, status, kind, package_id")
      .eq("id", data.orderId)
      .single();
    if (!order) throw new Error("ORDER_NOT_FOUND");
    if (order.status !== "pending") throw new Error("ALREADY_REVIEWED");

    if (!data.approve) {
      const { data: rejected } = await supabaseAdmin
        .from("orders")
        .select("coupon_code")
        .eq("id", order.id)
        .maybeSingle();
      if (rejected?.coupon_code)
        await supabaseAdmin.rpc("release_coupon", { _code: rejected.coupon_code });
      await supabaseAdmin.from("orders").update({ status: "rejected" }).eq("id", order.id);
      return { ok: true as const, status: "rejected" as const };
    }

    const XP_PER_GAME = 100;
    const XP_PER_LEVEL = 300;
    const GIFT_LEVELS = [3, 5, 10, 15, 20, 25];

    let deliveredGames = 0;
    let extraCredits = 0;

    if (order.kind === "package" && order.package_id) {
      const { data: pkg } = await supabaseAdmin
        .from("packages")
        .select("games_count")
        .eq("id", order.package_id)
        .single();
      extraCredits += pkg?.games_count ?? 0;
    } else {
      const { data: items } = await supabaseAdmin
        .from("order_items")
        .select("game_id")
        .eq("order_id", order.id);
      const gameIds = (items ?? [])
        .map((i) => i.game_id)
        .filter((id): id is string => Boolean(id));
      deliveredGames = gameIds.length;
      if (gameIds.length > 0) {
        await supabaseAdmin.from("user_games").upsert(
          gameIds.map((gameId) => ({ user_id: order.user_id, game_id: gameId, source: "order" })),
          { onConflict: "user_id,game_id" },
        );
      }
    }

    const { data: profile } = await supabaseAdmin
      .from("profiles")
      .select("xp, level, gift_credits")
      .eq("id", order.user_id)
      .single();

    const oldXp = profile?.xp ?? 0;
    const oldLevel = Math.floor(oldXp / XP_PER_LEVEL) + 1;
    const newXp = oldXp + deliveredGames * XP_PER_GAME;
    const newLevel = Math.floor(newXp / XP_PER_LEVEL) + 1;
    const milestoneGifts = GIFT_LEVELS.filter((l) => l > oldLevel && l <= newLevel).length;

    await supabaseAdmin
      .from("profiles")
      .update({
        xp: newXp,
        level: newLevel,
        gift_credits: (profile?.gift_credits ?? 0) + milestoneGifts + extraCredits,
      })
      .eq("id", order.user_id);

    await supabaseAdmin
      .from("orders")
      .update({ status: "confirmed", confirmed_at: new Date().toISOString() })
      .eq("id", order.id);

    return {
      ok: true as const,
      status: "confirmed" as const,
      xpAwarded: deliveredGames * XP_PER_GAME,
      newLevel,
      giftsAwarded: milestoneGifts + extraCredits,
    };
  });

/** Admin: list users with their profile + role. */
export const adminListUsers = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const { data: isAdmin } = await supabase.rpc("has_role", {
      _user_id: userId,
      _role: "admin",
    });
    if (!isAdmin) throw new Error("FORBIDDEN");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: profiles } = await supabaseAdmin
      .from("profiles")
      .select("id, email, display_name, xp, level, gift_credits, created_at")
      .order("created_at", { ascending: false });
    const { data: roles } = await supabaseAdmin
      .from("user_roles")
      .select("user_id, role")
      .eq("role", "admin");

    const adminIds = new Set((roles ?? []).map((r) => r.user_id));
    return (profiles ?? []).map((p) => ({ ...p, isAdmin: adminIds.has(p.id) }));
  });

/** Admin: grant or revoke the admin role. */
export const adminSetRole = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { targetUserId: string; makeAdmin: boolean }) => data)
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: isAdmin } = await supabase.rpc("has_role", {
      _user_id: userId,
      _role: "admin",
    });
    if (!isAdmin) throw new Error("FORBIDDEN");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    if (data.makeAdmin) {
      await supabaseAdmin
        .from("user_roles")
        .upsert({ user_id: data.targetUserId, role: "admin" }, { onConflict: "user_id,role" });
    } else {
      await supabaseAdmin
        .from("user_roles")
        .delete()
        .eq("user_id", data.targetUserId)
        .eq("role", "admin");
    }
    return { ok: true as const };
  });

/**
 * IP guard: more than 20 distinct devices signing in from one IP within an hour
 * blocks that IP for an hour.
 */
export const checkIpGuard = createServerFn({ method: "POST" })
  .inputValidator((data: { deviceId: string }) => data)
  .handler(async ({ data }) => {
    const forwarded = getRequestHeader("x-forwarded-for") ?? "";
    const ip =
      forwarded.split(",")[0]?.trim() ||
      getRequestHeader("cf-connecting-ip") ||
      getRequestHeader("x-real-ip") ||
      "unknown";
    if (ip === "unknown") return { allowed: true as const };

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const now = Date.now();

    const { data: block } = await supabaseAdmin
      .from("ip_blocks")
      .select("blocked_until")
      .eq("ip", ip)
      .maybeSingle();
    if (block && new Date(block.blocked_until).getTime() > now) {
      return { allowed: false as const, until: block.blocked_until };
    }

    const deviceId = data.deviceId.slice(0, 80);
    await supabaseAdmin.from("login_attempts").insert({ ip, device_id: deviceId });

    const since = new Date(now - 60 * 60 * 1000).toISOString();
    const { data: attempts } = await supabaseAdmin
      .from("login_attempts")
      .select("device_id")
      .eq("ip", ip)
      .gte("created_at", since);

    const distinct = new Set((attempts ?? []).map((a) => a.device_id)).size;
    if (distinct > 20) {
      const until = new Date(now + 60 * 60 * 1000).toISOString();
      await supabaseAdmin
        .from("ip_blocks")
        .upsert({ ip, blocked_until: until, reason: "too many devices" }, { onConflict: "ip" });
      return { allowed: false as const, until };
    }

    return { allowed: true as const };
  });
