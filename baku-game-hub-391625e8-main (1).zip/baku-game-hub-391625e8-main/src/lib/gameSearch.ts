const ROMAN: Record<string, string> = {
  i: "1",
  ii: "2",
  iii: "3",
  iv: "4",
  v: "5",
  vi: "6",
  vii: "7",
  viii: "8",
  ix: "9",
  x: "10",
  xi: "11",
  xii: "12",
  xiii: "13",
  xiv: "14",
  xv: "15",
};

const ARABIC_TO_ROMAN: Record<string, string> = Object.fromEntries(
  Object.entries(ROMAN).map(([r, a]) => [a, r]),
);

const STOP_WORDS = new Set(["the", "of", "and", "a", "an", "de", "la"]);

/** Manual nickname map — key is a lowercase substring of the title. */
const MANUAL_ALIASES: Array<{ match: string; aliases: string[] }> = [
  { match: "grand theft auto", aliases: ["gta"] },
  { match: "counter-strike", aliases: ["cs", "ks"] },
  { match: "counter strike", aliases: ["cs"] },
  { match: "global offensive", aliases: ["csgo", "cs go", "cs2"] },
  { match: "call of duty", aliases: ["cod"] },
  { match: "modern warfare", aliases: ["mw", "cod mw"] },
  { match: "black ops", aliases: ["bo", "cod bo"] },
  { match: "red dead redemption", aliases: ["rdr", "rdr2"] },
  { match: "red dead", aliases: ["rdr"] },
  { match: "assassin's creed", aliases: ["ac", "assassins creed"] },
  { match: "assassins creed", aliases: ["ac"] },
  { match: "need for speed", aliases: ["nfs"] },
  { match: "the elder scrolls", aliases: ["tes", "skyrim"] },
  { match: "player unknown", aliases: ["pubg"] },
  { match: "playerunknown", aliases: ["pubg"] },
  { match: "battlegrounds", aliases: ["pubg"] },
  { match: "resident evil", aliases: ["re", "biohazard"] },
  { match: "the last of us", aliases: ["tlou", "last of us"] },
  { match: "the witcher", aliases: ["witcher", "tw3"] },
  { match: "god of war", aliases: ["gow"] },
  { match: "battlefield", aliases: ["bf"] },
  { match: "watch dogs", aliases: ["wd", "watchdogs"] },
  { match: "far cry", aliases: ["fc", "farcry"] },
  { match: "ea sports fc", aliases: ["fifa", "ea fc", "fc"] },
  { match: "ea sports f1", aliases: ["f1"] },
  { match: "efootball", aliases: ["pes", "e football"] },
  { match: "pro evolution soccer", aliases: ["pes"] },
  { match: "mortal kombat", aliases: ["mk"] },
  { match: "tom clancy", aliases: ["tc"] },
  { match: "rainbow six", aliases: ["r6", "rainbow6"] },
  { match: "grand theft auto v", aliases: ["gta 5", "gta5", "gtav"] },
  { match: "cyberpunk", aliases: ["cp2077", "cyber punk"] },
  { match: "elden ring", aliases: ["er"] },
  { match: "metal gear solid", aliases: ["mgs"] },
  { match: "sekiro", aliases: ["sekiro shadows"] },
  { match: "dying light", aliases: ["dl"] },
  { match: "dead by daylight", aliases: ["dbd"] },
  { match: "left 4 dead", aliases: ["l4d"] },
  { match: "grand turismo", aliases: ["gt"] },
  { match: "the sims", aliases: ["sims"] },
  { match: "minecraft", aliases: ["mc"] },
  { match: "hogwarts legacy", aliases: ["hl", "harry potter"] },
  { match: "star wars", aliases: ["sw"] },
  { match: "marvel's spider-man", aliases: ["spiderman", "spider man"] },
  { match: "spider-man", aliases: ["spiderman"] },
  { match: "horizon zero dawn", aliases: ["hzd"] },
  { match: "horizon forbidden west", aliases: ["hfw"] },
  { match: "forza horizon", aliases: ["fh", "forza"] },
  { match: "forza motorsport", aliases: ["fm", "forza"] },
  { match: "euro truck simulator", aliases: ["ets", "ets2"] },
  { match: "american truck simulator", aliases: ["ats"] },
  { match: "grand strategy", aliases: [] },
  { match: "world of tanks", aliases: ["wot"] },
  { match: "world of warcraft", aliases: ["wow"] },
  { match: "the legend of zelda", aliases: ["zelda", "totk", "botw"] },
  { match: "baldur's gate", aliases: ["bg3", "baldurs gate"] },
  { match: "ghost of tsushima", aliases: ["got"] },
  { match: "it takes two", aliases: ["itt"] },
  { match: "nba 2k", aliases: ["nba"] },
  { match: "wwe 2k", aliases: ["wwe"] },
];

function normalize(value: string) {
  return value
    .toLowerCase()
    .replace(/[’'`]/g, "")
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

/** All searchable strings for a game title (title + generated nicknames). */
export function buildSearchTokens(title: string, extra: string[] = []): string[] {
  const norm = normalize(title);
  const tokens = new Set<string>([norm, norm.replace(/\s+/g, "")]);

  for (const e of extra) {
    const n = normalize(e);
    if (n) {
      tokens.add(n);
      tokens.add(n.replace(/\s+/g, ""));
    }
  }

  const words = norm.split(" ").filter(Boolean);

  // roman <-> arabic variants
  const swapped = words.map((w) => ROMAN[w] ?? ARABIC_TO_ROMAN[w] ?? w);
  tokens.add(swapped.join(" "));
  tokens.add(swapped.join(""));

  // acronym from significant words, keeping numbers
  const significant = words.filter((w) => !STOP_WORDS.has(w));
  const acronym = significant
    .map((w) => (/^\d+$/.test(w) ? w : (ROMAN[w] ?? w[0])))
    .join("");
  if (acronym.length >= 2) {
    tokens.add(acronym);
    tokens.add(acronym.replace(/(\d+)/, " $1").trim());
  }

  // manual nicknames, combined with any trailing number/roman in the title
  const numberPart = swapped.find((w) => /^\d+$/.test(w));
  for (const entry of MANUAL_ALIASES) {
    if (!norm.includes(normalize(entry.match))) continue;
    for (const alias of entry.aliases) {
      const a = normalize(alias);
      tokens.add(a);
      tokens.add(a.replace(/\s+/g, ""));
      if (numberPart) {
        tokens.add(`${a} ${numberPart}`);
        tokens.add(`${a}${numberPart}`);
      }
    }
  }

  return [...tokens].filter(Boolean);
}

export function matchesGame(title: string, query: string, extra: string[] = []) {
  const needle = normalize(query);
  if (!needle) return true;
  const compact = needle.replace(/\s+/g, "");
  const tokens = buildSearchTokens(title, extra);
  if (
    tokens.some(
      (token) => token.includes(needle) || token.replace(/\s+/g, "").includes(compact),
    )
  ) {
    return true;
  }
  // every word of the query must match some token (handles "ac valhalla", "gta san andreas")
  const parts = needle.split(" ").filter(Boolean);
  if (parts.length < 2) return false;
  return parts.every((part) =>
    tokens.some((token) => token.includes(part) || token.replace(/\s+/g, "").includes(part)),
  );
}
