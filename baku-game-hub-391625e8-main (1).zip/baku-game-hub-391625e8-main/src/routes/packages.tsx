import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Sparkles, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/hooks/useAuth";
import { useI18n } from "@/i18n";
import { placePackageOrder } from "@/lib/shop.functions";
import { BRAND, formatPrice, waLink } from "@/lib/constants";

export const Route = createFileRoute("/packages")({
  head: () => ({
    meta: [
      { title: "Xüsusi Paketlər — BakuSteamShop" },
      {
        name: "description",
        content: "Sərfəli oyun paketləri: 3 oyun 10 ₼-dən. Paketi alın, oyunları özünüz seçin.",
      },
      { property: "og:title", content: "Xüsusi Paketlər — BakuSteamShop" },
      { property: "og:description", content: "Sərfəli oyun paketləri: 3 oyun 10 ₼-dən." },
    ],
  }),
  component: PackagesPage,
});

function PackagesPage() {
  const { t } = useI18n();
  const { data: session } = useSession();
  const router = useRouter();
  const buy = useServerFn(placePackageOrder);

  const packages = useQuery({
    queryKey: ["packages"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("packages")
        .select("id, title, description, price, games_count")
        .eq("active", true)
        .order("price", { ascending: true });
      if (error) throw error;
      return data ?? [];
    },
  });

  const order = useMutation({
    mutationFn: async (packageId: string) => buy({ data: { packageId } }),
    onSuccess: (res) => {
      const text = `${BRAND} — paket sifarişi\n\n${res.title} (${res.gamesCount} oyun)\nQiymət: ${res.total} AZN\nSifariş №: ${res.orderId.slice(0, 8)}\nİstifadəçi: ${session?.user.email ?? ""}`;
      toast.success(t("cart.sent"));
      window.open(waLink(text), "_blank", "noopener");
      void router.navigate({ to: "/orders" });
    },
    onError: () => toast.error(t("common.error")),
  });

  return (
    <div className="mx-auto w-full max-w-6xl px-4 py-12">
      <h1 className="font-display text-3xl font-bold sm:text-4xl">
        <span className="text-cyan">{t("pkg.title")}</span>
      </h1>
      <p className="mt-2 max-w-xl text-sm text-muted-foreground">{t("pkg.hint")}</p>

      {packages.isLoading ? (
        <p className="mt-10 text-muted-foreground">{t("common.loading")}</p>
      ) : (packages.data ?? []).length === 0 ? (
        <p className="mt-10 text-muted-foreground">{t("pkg.empty")}</p>
      ) : (
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {(packages.data ?? []).map((p, i) => (
            <div
              key={p.id}
              className="animate-fade-up rounded-2xl border border-accent/30 bg-card p-6 card-elevated transition-transform hover:-translate-y-1 hover:shadow-neon"
              style={{ animationDelay: `${i * 50}ms` }}
            >
              <span className="grid size-10 place-items-center rounded-xl bg-primary/15 text-primary">
                <Sparkles className="size-5" />
              </span>
              <h2 className="mt-4 font-display text-xl font-bold">{p.title}</h2>
              <p className="mt-1 text-sm text-muted-foreground">{p.description}</p>
              <p className="mt-4 font-display text-3xl font-black text-gold">
                {formatPrice(Number(p.price))}
              </p>
              <p className="text-xs text-muted-foreground">
                {p.games_count} {t("pkg.games")}
              </p>
              {session ? (
                <Button
                  className="mt-5 w-full shadow-gold"
                  disabled={order.isPending}
                  onClick={() => order.mutate(p.id)}
                >
                  {order.isPending ? <Loader2 className="size-4 animate-spin" /> : null}
                  {t("pkg.buy")}
                </Button>
              ) : (
                <Button asChild variant="outline" className="mt-5 w-full">
                  <Link to="/auth">{t("game.loginToBuy")}</Link>
                </Button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
