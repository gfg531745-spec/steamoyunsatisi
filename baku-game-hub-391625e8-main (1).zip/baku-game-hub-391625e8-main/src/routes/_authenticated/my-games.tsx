import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { Copy, Eye, EyeOff, Gift, KeyRound, Loader2, MessageCircle } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { supabase } from "@/integrations/supabase/client";
import { useProfile } from "@/hooks/useAuth";
import { useGames } from "@/hooks/useCart";
import { useI18n } from "@/i18n";
import { claimFreeGame, getOwnedCredentials } from "@/lib/shop.functions";
import { BRAND, coverFor, levelProgress, waLink } from "@/lib/constants";

export const Route = createFileRoute("/_authenticated/my-games")({
  head: () => ({
    meta: [
      { title: "Oyunlarım — BakuSteamShop" },
      { name: "description", content: "Aldığınız oyunlar, hesab məlumatları və OTP kodu sorğusu." },
      { property: "og:title", content: "Oyunlarım — BakuSteamShop" },
      { property: "og:description", content: "Aldığınız oyunlar və hesab məlumatları." },
    ],
  }),
  component: MyGamesPage,
});

function MyGamesPage() {
  const { t } = useI18n();
  const queryClient = useQueryClient();
  const { data: profile } = useProfile();
  const { data: allGames } = useGames();
  const [giftOpen, setGiftOpen] = useState(false);
  const claim = useServerFn(claimFreeGame);

  const myGames = useQuery({
    queryKey: ["my-games", "list"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("user_games")
        .select("id, source, created_at, games ( id, title, cover_url, steam_appid )")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  const claimMutation = useMutation({
    mutationFn: async (gameId: string) => claim({ data: { gameId } }),
    onSuccess: () => {
      toast.success(t("my.giftClaimed"));
      setGiftOpen(false);
      void queryClient.invalidateQueries();
    },
    onError: () => toast.error(t("common.error")),
  });

  const progress = levelProgress(profile?.xp ?? 0);
  const ownedIds = new Set(
    (myGames.data ?? []).map((r) => (r.games as { id: string } | null)?.id).filter(Boolean),
  );

  return (
    <div className="mx-auto w-full max-w-6xl px-4 py-10">
      <div className="flex flex-col gap-6 rounded-2xl border border-border/70 bg-card p-6 card-elevated sm:flex-row sm:items-center sm:justify-between">
        <div className="w-full">
          <p className="text-sm text-muted-foreground">{profile?.email}</p>
          <p className="font-display text-2xl font-bold">
            {t("my.level")} <span className="text-gold">{progress.level}</span>
          </p>
          <Progress value={progress.percent} className="mt-3 h-2" />
          <p className="mt-1 text-xs text-muted-foreground">
            {profile?.xp ?? 0} {t("my.xp")} · {progress.inLevel}/{progress.needed}
          </p>
        </div>
        <div className="shrink-0 rounded-xl border border-primary/40 bg-primary/10 p-4 text-center">
          <Gift className="mx-auto size-5 text-primary" />
          <p className="mt-1 font-display text-2xl font-bold text-primary">
            {profile?.gift_credits ?? 0}
          </p>
          <p className="text-xs text-muted-foreground">{t("my.gifts")}</p>
          <Button
            size="sm"
            className="mt-3 w-full"
            disabled={(profile?.gift_credits ?? 0) < 1}
            onClick={() => setGiftOpen(true)}
          >
            {t("my.chooseGift")}
          </Button>
        </div>
      </div>

      <h1 className="mt-10 font-display text-3xl font-bold">{t("my.title")}</h1>

      {myGames.isLoading ? (
        <p className="mt-6 text-muted-foreground">{t("common.loading")}</p>
      ) : (myGames.data ?? []).length === 0 ? (
        <p className="mt-6 text-muted-foreground">{t("my.empty")}</p>
      ) : (
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {(myGames.data ?? []).map((row) => {
            const game = row.games as {
              id: string;
              title: string;
              cover_url: string | null;
              steam_appid: number | null;
            } | null;
            if (!game) return null;
            return <OwnedGameCard key={row.id} game={game} />;
          })}
        </div>
      )}

      <Dialog open={giftOpen} onOpenChange={setGiftOpen}>
        <DialogContent className="max-h-[80vh] max-w-3xl overflow-y-auto">
          <DialogTitle className="font-display">{t("my.chooseGift")}</DialogTitle>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {(allGames ?? [])
              .filter((g) => !ownedIds.has(g.id))
              .map((g) => (
                <button
                  key={g.id}
                  onClick={() => claimMutation.mutate(g.id)}
                  disabled={claimMutation.isPending}
                  className="overflow-hidden rounded-xl border border-border/70 bg-card text-left transition-all hover:border-primary hover:shadow-gold"
                >
                  <img src={coverFor(g)} alt={g.title} className="aspect-[2/3] w-full object-cover" />
                  <p className="line-clamp-2 p-2 text-xs font-medium">{g.title}</p>
                </button>
              ))}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function OwnedGameCard({
  game,
}: {
  game: { id: string; title: string; cover_url: string | null; steam_appid: number | null };
}) {
  const { t } = useI18n();
  const [open, setOpen] = useState(false);
  const fetchCreds = useServerFn(getOwnedCredentials);

  const creds = useQuery({
    queryKey: ["creds", game.id],
    enabled: open,
    queryFn: async () => fetchCreds({ data: { gameId: game.id } }),
  });

  function copy(value: string) {
    void navigator.clipboard.writeText(value);
    toast.success(t("my.copied"));
  }

  return (
    <div className="animate-fade-up overflow-hidden rounded-2xl border border-border/70 bg-card card-elevated">
      <div className="flex gap-3 p-3">
        <img src={coverFor(game)} alt={game.title} className="h-28 w-20 rounded-md object-cover" />
        <div className="flex min-w-0 flex-1 flex-col">
          <p className="line-clamp-2 font-semibold">{game.title}</p>
          <Button
            size="sm"
            variant="secondary"
            className="mt-auto gap-2"
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
            {open ? t("my.hide") : t("my.show")}
          </Button>
        </div>
      </div>

      {open ? (
        <div className="animate-fade-in space-y-2 border-t border-border/70 bg-secondary/40 p-3 text-sm">
          {creds.isLoading ? (
            <p className="flex items-center gap-2 text-muted-foreground">
              <Loader2 className="size-4 animate-spin" /> {t("common.loading")}
            </p>
          ) : creds.data?.email || creds.data?.password ? (
            <>
              <Field
                label={t("my.accEmail")}
                value={creds.data.email ?? "—"}
                onCopy={() => copy(creds.data?.email ?? "")}
              />
              <Field
                label={t("my.accPass")}
                value={creds.data.password ?? "—"}
                onCopy={() => copy(creds.data?.password ?? "")}
              />
              {creds.data.note ? (
                <p className="text-xs text-muted-foreground">{creds.data.note}</p>
              ) : null}
            </>
          ) : (
            <p className="text-muted-foreground">{t("my.noCreds")}</p>
          )}

          <Button asChild size="sm" variant="outline" className="w-full gap-2">
            <a
              href={waLink(
                `${BRAND} — OTP kodu sorğusu\nOyun: ${game.title}\nHesab: ${creds.data?.email ?? "-"}`,
              )}
              target="_blank"
              rel="noreferrer"
            >
              <MessageCircle className="size-4" />
              {t("my.otp")}
            </a>
          </Button>
        </div>
      ) : null}
    </div>
  );
}

function Field({
  label,
  value,
  onCopy,
}: {
  label: string;
  value: string;
  onCopy: () => void;
}) {
  return (
    <div className="flex items-center gap-2 rounded-md border border-border/70 bg-background/60 px-2 py-1.5">
      <KeyRound className="size-3.5 shrink-0 text-muted-foreground" />
      <div className="min-w-0 flex-1">
        <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</p>
        <p className="truncate font-mono text-xs">{value}</p>
      </div>
      <Button size="icon" variant="ghost" className="size-7" onClick={onCopy}>
        <Copy className="size-3.5" />
      </Button>
    </div>
  );
}
