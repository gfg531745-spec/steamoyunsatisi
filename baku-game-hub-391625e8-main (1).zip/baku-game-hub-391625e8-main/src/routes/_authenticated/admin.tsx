import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { Check, Loader2, Plus, ShieldCheck, Trash2, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { useIsAdmin } from "@/hooks/useAuth";
import { useI18n } from "@/i18n";
import { adminListUsers, adminReviewOrder, adminSetRole } from "@/lib/shop.functions";
import { coverFor, formatPrice } from "@/lib/constants";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    meta: [
      { title: "Admin panel — BakuSteamShop" },
      { name: "description", content: "Oyunları, sifarişləri, paketləri və istifadəçiləri idarə edin." },
      { property: "og:title", content: "Admin panel — BakuSteamShop" },
      { property: "og:description", content: "Mağazanın idarəetmə paneli." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminPage,
});

function slugify(v: string) {
  return v
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 80);
}

function AdminPage() {
  const { t } = useI18n();
  const { data: isAdmin, isLoading } = useIsAdmin();

  if (isLoading) return <p className="p-10 text-muted-foreground">{t("common.loading")}</p>;
  if (!isAdmin)
    return (
      <div className="mx-auto max-w-md px-4 py-20 text-center">
        <ShieldCheck className="mx-auto size-10 text-destructive" />
        <p className="mt-4 text-muted-foreground">{t("admin.noAccess")}</p>
      </div>
    );

  return (
    <div className="mx-auto w-full max-w-6xl px-4 py-10">
      <h1 className="font-display text-3xl font-bold">{t("admin.title")}</h1>
      <Tabs defaultValue="orders" className="mt-6">
        <TabsList className="flex-wrap">
          <TabsTrigger value="orders">{t("admin.orders")}</TabsTrigger>
          <TabsTrigger value="games">{t("admin.games")}</TabsTrigger>
          <TabsTrigger value="packages">{t("admin.packages")}</TabsTrigger>
          <TabsTrigger value="users">{t("admin.users")}</TabsTrigger>
        </TabsList>
        <TabsContent value="orders" className="mt-6">
          <OrdersTab />
        </TabsContent>
        <TabsContent value="games" className="mt-6">
          <GamesTab />
        </TabsContent>
        <TabsContent value="packages" className="mt-6">
          <PackagesTab />
        </TabsContent>
        <TabsContent value="users" className="mt-6">
          <UsersTab />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function OrdersTab() {
  const { t } = useI18n();
  const queryClient = useQueryClient();
  const review = useServerFn(adminReviewOrder);

  const orders = useQuery({
    queryKey: ["admin", "orders"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("orders")
        .select("id, status, kind, total, created_at, user_id, order_items ( id, title, price )")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  const emails = useQuery({
    queryKey: ["admin", "profile-emails"],
    queryFn: async () => {
      const { data } = await supabase.from("profiles").select("id, email");
      return new Map((data ?? []).map((p) => [p.id, p.email]));
    },
  });

  const act = useMutation({
    mutationFn: async (input: { orderId: string; approve: boolean }) => review({ data: input }),
    onSuccess: () => {
      toast.success(t("admin.saved"));
      void queryClient.invalidateQueries();
    },
    onError: () => toast.error(t("common.error")),
  });

  if (orders.isLoading) return <p className="text-muted-foreground">{t("common.loading")}</p>;

  return (
    <ul className="space-y-4">
      {(orders.data ?? []).map((o) => {
        const email = emails.data?.get(o.user_id) ?? null;
        return (
          <li key={o.id} className="rounded-xl border border-border/70 bg-card p-4 card-elevated">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="font-mono text-xs text-muted-foreground">#{o.id.slice(0, 8)}</p>
                <p className="text-sm font-semibold">{email ?? o.user_id.slice(0, 8)}</p>
              </div>
              <span className="rounded-full bg-secondary px-3 py-1 text-xs font-semibold">
                {t(
                  o.status === "confirmed"
                    ? "status.confirmed"
                    : o.status === "rejected"
                      ? "status.rejected"
                      : "status.pending",
                )}
              </span>
            </div>
            <ul className="mt-3 space-y-1 text-sm">
              {o.order_items.map((i) => (
                <li key={i.id} className="flex justify-between gap-3">
                  <span className="truncate">{i.title}</span>
                  <span className="text-muted-foreground">{formatPrice(Number(i.price))}</span>
                </li>
              ))}
            </ul>
            <div className="mt-3 flex items-center justify-between gap-3">
              <span className="font-display font-bold text-primary">
                {formatPrice(Number(o.total))}
              </span>
              {o.status === "pending" ? (
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    disabled={act.isPending}
                    onClick={() => act.mutate({ orderId: o.id, approve: true })}
                    className="gap-1"
                  >
                    <Check className="size-4" />
                    {t("admin.confirm")}
                  </Button>
                  <Button
                    size="sm"
                    variant="destructive"
                    disabled={act.isPending}
                    onClick={() => act.mutate({ orderId: o.id, approve: false })}
                    className="gap-1"
                  >
                    <X className="size-4" />
                    {t("admin.reject")}
                  </Button>
                </div>
              ) : null}
            </div>
          </li>
        );
      })}
    </ul>
  );
}

function GamesTab() {
  const { t } = useI18n();
  const queryClient = useQueryClient();
  const [form, setForm] = useState({ title: "", price: "4", cover: "", appid: "" });

  const games = useQuery({
    queryKey: ["admin", "games"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("games")
        .select("id, title, cover_url, steam_appid, price, sort_order")
        .order("sort_order");
      if (error) throw error;
      return data ?? [];
    },
  });

  const creds = useQuery({
    queryKey: ["admin", "creds"],
    queryFn: async () => {
      const { data } = await supabase
        .from("game_credentials")
        .select("game_id, account_email, account_password");
      return new Map((data ?? []).map((c) => [c.game_id, c]));
    },
  });

  const addGame = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("games").insert({
        title: form.title.trim(),
        slug: `${slugify(form.title)}-${Date.now().toString(36)}`,
        cover_url: form.cover.trim() || null,
        steam_appid: form.appid ? Number(form.appid) : null,
        price: Number(form.price) || 4,
        sort_order: (games.data?.length ?? 0) + 1,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success(t("admin.saved"));
      setForm({ title: "", price: "4", cover: "", appid: "" });
      void queryClient.invalidateQueries({ queryKey: ["admin", "games"] });
      void queryClient.invalidateQueries({ queryKey: ["games"] });
    },
    onError: () => toast.error(t("common.error")),
  });

  const removeGame = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("games").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      void queryClient.invalidateQueries();
      toast.success(t("admin.saved"));
    },
  });

  return (
    <div className="space-y-8">
      <section className="rounded-xl border border-border/70 bg-card p-5 card-elevated">
        <h2 className="font-display text-lg font-bold">{t("admin.addGame")}</h2>
        <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <div className="space-y-1.5">
            <Label>{t("admin.gameTitle")}</Label>
            <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
          </div>
          <div className="space-y-1.5">
            <Label>{t("admin.price")}</Label>
            <Input value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} />
          </div>
          <div className="space-y-1.5">
            <Label>{t("admin.appid")}</Label>
            <Input value={form.appid} onChange={(e) => setForm({ ...form, appid: e.target.value })} />
          </div>
          <div className="space-y-1.5">
            <Label>{t("admin.cover")}</Label>
            <Input value={form.cover} onChange={(e) => setForm({ ...form, cover: e.target.value })} />
          </div>
        </div>
        <Button
          className="mt-4 gap-2 shadow-gold"
          disabled={!form.title.trim() || addGame.isPending}
          onClick={() => addGame.mutate()}
        >
          {addGame.isPending ? <Loader2 className="size-4 animate-spin" /> : <Plus className="size-4" />}
          {t("admin.save")}
        </Button>
      </section>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {(games.data ?? []).map((g) => (
          <GameAdminRow
            key={g.id}
            game={g}
            creds={creds.data?.get(g.id) ?? null}
            onDelete={() => removeGame.mutate(g.id)}
          />
        ))}
      </div>
    </div>
  );
}

function GameAdminRow({
  game,
  creds,
  onDelete,
}: {
  game: { id: string; title: string; cover_url: string | null; steam_appid: number | null };
  creds: { account_email: string | null; account_password: string | null } | null;
  onDelete: () => void;
}) {
  const { t } = useI18n();
  const queryClient = useQueryClient();
  const [email, setEmail] = useState(creds?.account_email ?? "");
  const [password, setPassword] = useState(creds?.account_password ?? "");

  const save = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("game_credentials").upsert(
        {
          game_id: game.id,
          account_email: email || null,
          account_password: password || null,
          updated_at: new Date().toISOString(),
        },
        { onConflict: "game_id" },
      );
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success(t("admin.saved"));
      void queryClient.invalidateQueries({ queryKey: ["admin", "creds"] });
    },
    onError: () => toast.error(t("common.error")),
  });

  return (
    <div className="rounded-xl border border-border/70 bg-card p-3 card-elevated">
      <div className="flex gap-3">
        <img src={coverFor(game)} alt={game.title} className="h-24 w-16 rounded object-cover" />
        <div className="min-w-0 flex-1">
          <p className="line-clamp-2 text-sm font-semibold">{game.title}</p>
          <Button size="icon" variant="ghost" className="mt-1 size-8" onClick={onDelete}>
            <Trash2 className="size-4 text-destructive" />
          </Button>
        </div>
      </div>
      <div className="mt-3 space-y-2">
        <Input
          placeholder={t("admin.accEmail")}
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="h-8 text-xs"
        />
        <Input
          placeholder={t("admin.accPass")}
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="h-8 text-xs"
        />
        <Button size="sm" variant="secondary" className="w-full" onClick={() => save.mutate()}>
          {t("admin.save")}
        </Button>
      </div>
    </div>
  );
}

function PackagesTab() {
  const { t } = useI18n();
  const queryClient = useQueryClient();
  const [form, setForm] = useState({ title: "", description: "", price: "10", count: "3" });

  const packages = useQuery({
    queryKey: ["admin", "packages"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("packages")
        .select("id, title, description, price, games_count")
        .order("price");
      if (error) throw error;
      return data ?? [];
    },
  });

  const add = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("packages").insert({
        title: form.title.trim(),
        description: form.description.trim() || null,
        price: Number(form.price) || 0,
        games_count: Number(form.count) || 1,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success(t("admin.saved"));
      setForm({ title: "", description: "", price: "10", count: "3" });
      void queryClient.invalidateQueries();
    },
    onError: () => toast.error(t("common.error")),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("packages").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => void queryClient.invalidateQueries(),
  });

  return (
    <div className="space-y-8">
      <section className="rounded-xl border border-border/70 bg-card p-5 card-elevated">
        <h2 className="font-display text-lg font-bold">{t("admin.addPackage")}</h2>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <div className="space-y-1.5">
            <Label>{t("admin.gameTitle")}</Label>
            <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
          </div>
          <div className="space-y-1.5">
            <Label>{t("admin.price")}</Label>
            <Input value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} />
          </div>
          <div className="space-y-1.5">
            <Label>{t("admin.gamesCount")}</Label>
            <Input value={form.count} onChange={(e) => setForm({ ...form, count: e.target.value })} />
          </div>
          <div className="space-y-1.5">
            <Label>{t("admin.desc")}</Label>
            <Textarea
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              rows={2}
            />
          </div>
        </div>
        <Button
          className="mt-4 shadow-gold"
          disabled={!form.title.trim() || add.isPending}
          onClick={() => add.mutate()}
        >
          {t("admin.save")}
        </Button>
      </section>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {(packages.data ?? []).map((p) => (
          <div key={p.id} className="rounded-xl border border-border/70 bg-card p-4 card-elevated">
            <p className="font-display font-bold">{p.title}</p>
            <p className="text-sm text-muted-foreground">{p.description}</p>
            <p className="mt-2 text-primary">
              {formatPrice(Number(p.price))} · {p.games_count} {t("pkg.games")}
            </p>
            <Button size="sm" variant="ghost" className="mt-2" onClick={() => remove.mutate(p.id)}>
              <Trash2 className="size-4 text-destructive" />
            </Button>
          </div>
        ))}
      </div>
    </div>
  );
}

function UsersTab() {
  const { t } = useI18n();
  const queryClient = useQueryClient();
  const list = useServerFn(adminListUsers);
  const setRole = useServerFn(adminSetRole);

  const users = useQuery({
    queryKey: ["admin", "users"],
    queryFn: async () => list({ data: undefined as never }),
    retry: 1,
  });

  const toggle = useMutation({
    mutationFn: async (input: { targetUserId: string; makeAdmin: boolean }) =>
      setRole({ data: input }),
    onSuccess: () => {
      toast.success(t("admin.saved"));
      void queryClient.invalidateQueries({ queryKey: ["admin", "users"] });
    },
    onError: () => toast.error(t("common.error")),
  });

  if (users.isPending) return <p className="text-muted-foreground">{t("common.loading")}</p>;

  // Never hang on "loading" when the request fails — show the reason + a retry.
  if (users.isError)
    return (
      <div className="space-y-3 rounded-xl border border-destructive/40 bg-destructive/10 p-4">
        <p className="text-sm font-medium">{t("admin.loadError")}</p>
        <p className="text-xs text-muted-foreground">
          {users.error instanceof Error ? users.error.message : ""}
        </p>
        <Button size="sm" variant="secondary" onClick={() => void users.refetch()}>
          {t("common.retry")}
        </Button>
      </div>
    );


  return (
    <div className="overflow-x-auto rounded-xl border border-border/70 bg-card card-elevated">
      <table className="w-full min-w-[600px] text-sm">
        <thead className="bg-secondary/50 text-left text-xs uppercase tracking-wider text-muted-foreground">
          <tr>
            <th className="p-3">{t("admin.user")}</th>
            <th className="p-3">{t("my.level")}</th>
            <th className="p-3">{t("my.xp")}</th>
            <th className="p-3">{t("my.gifts")}</th>
            <th className="p-3" />
          </tr>
        </thead>
        <tbody>
          {(users.data ?? []).map((u) => (
            <tr key={u.id} className="border-t border-border/60">
              <td className="p-3">
                <p className="font-medium">{u.display_name ?? "—"}</p>
                <p className="text-xs text-muted-foreground">{u.email}</p>
              </td>
              <td className="p-3">{u.level}</td>
              <td className="p-3">{u.xp}</td>
              <td className="p-3">{u.gift_credits}</td>
              <td className="p-3 text-right">
                <Button
                  size="sm"
                  variant={u.isAdmin ? "destructive" : "secondary"}
                  onClick={() => toggle.mutate({ targetUserId: u.id, makeAdmin: !u.isAdmin })}
                >
                  {u.isAdmin ? t("admin.removeAdmin") : t("admin.makeAdmin")}
                </Button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
