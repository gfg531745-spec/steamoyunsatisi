import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useI18n } from "@/i18n";
import { formatPrice } from "@/lib/constants";

export const Route = createFileRoute("/_authenticated/orders")({
  head: () => ({
    meta: [
      { title: "Sifarişlərim — BakuSteamShop" },
      { name: "description", content: "Sifarişlərinizin statusunu izləyin." },
      { property: "og:title", content: "Sifarişlərim — BakuSteamShop" },
      { property: "og:description", content: "Sifarişlərinizin statusunu izləyin." },
    ],
  }),
  component: OrdersPage,
});

const statusKey = {
  pending: "status.pending",
  confirmed: "status.confirmed",
  rejected: "status.rejected",
} as const;

function OrdersPage() {
  const { t } = useI18n();

  const orders = useQuery({
    queryKey: ["orders", "mine"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("orders")
        .select("id, status, kind, total, created_at, order_items ( id, title, price )")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  return (
    <div className="mx-auto w-full max-w-4xl px-4 py-10">
      <h1 className="font-display text-3xl font-bold">{t("orders.title")}</h1>

      {orders.isLoading ? (
        <p className="mt-8 text-muted-foreground">{t("common.loading")}</p>
      ) : (orders.data ?? []).length === 0 ? (
        <p className="mt-8 text-muted-foreground">{t("orders.empty")}</p>
      ) : (
        <ul className="mt-8 space-y-4">
          {(orders.data ?? []).map((o) => (
            <li key={o.id} className="animate-fade-up rounded-xl border border-border/70 bg-card p-4 card-elevated">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="font-mono text-xs text-muted-foreground">#{o.id.slice(0, 8)}</p>
                <span
                  className={`rounded-full px-3 py-1 text-xs font-semibold ${
                    o.status === "confirmed"
                      ? "bg-success/20 text-success"
                      : o.status === "rejected"
                        ? "bg-destructive/20 text-destructive"
                        : "bg-primary/20 text-primary"
                  }`}
                >
                  {t(statusKey[(o.status as keyof typeof statusKey) ?? "pending"] ?? "status.pending")}
                </span>
              </div>
              <ul className="mt-3 space-y-1 text-sm">
                {o.order_items.map((i) => (
                  <li key={i.id} className="flex justify-between gap-4">
                    <span className="truncate">{i.title}</span>
                    <span className="text-muted-foreground">{formatPrice(Number(i.price))}</span>
                  </li>
                ))}
              </ul>
              <p className="mt-3 text-right font-display font-bold text-primary">
                {formatPrice(Number(o.total))}
              </p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
