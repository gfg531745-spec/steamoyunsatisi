import { createFileRoute, useRouter } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Gamepad2, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { useI18n } from "@/i18n";
import { useSession } from "@/hooks/useAuth";
import { checkIpGuard } from "@/lib/shop.functions";
import { authRedirectOrigin } from "@/lib/site";
import { AuthTransition } from "@/components/AuthTransition";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Daxil ol — BakuSteamShop" },
      { name: "description", content: "BakuSteamShop hesabınıza daxil olun və ya qeydiyyatdan keçin." },
      { property: "og:title", content: "Daxil ol — BakuSteamShop" },
      { property: "og:description", content: "Hesabınıza daxil olun və oyunlarınızı idarə edin." },
    ],
  }),
  component: AuthPage,
});

function deviceId() {
  let id = window.localStorage.getItem("bsa-device");
  if (!id) {
    id = crypto.randomUUID();
    window.localStorage.setItem("bsa-device", id);
  }
  return id;
}

function AuthPage() {
  const { t } = useI18n();
  const router = useRouter();
  const { data: session } = useSession();
  const guard = useServerFn(checkIpGuard);

  const [mode, setMode] = useState<"in" | "up" | "forgot" | "otp">("in");
  const [otpType, setOtpType] = useState<"signup" | "recovery">("signup");
  const [otp, setOtp] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const [cooldown, setCooldown] = useState(0);
  const [leaving, setLeaving] = useState(false);

  useEffect(() => {
    if (cooldown <= 0) return;
    const id = window.setTimeout(() => setCooldown((c) => c - 1), 1000);
    return () => window.clearTimeout(id);
  }, [cooldown]);

  useEffect(() => {
    if (session && !leaving) void router.navigate({ to: "/", replace: true });
  }, [session, router, leaving]);


  /** OTP/code errors and password errors must never be mixed up. */
  function otpError(err: unknown) {
    const raw = err instanceof Error ? err.message.toLowerCase() : "";
    if (raw.includes("rate") || raw.includes("security purposes")) return t("auth.tooMany");
    if (
      raw.includes("expired") ||
      raw.includes("invalid") ||
      raw.includes("token") ||
      raw.includes("otp")
    )
      return t("auth.codeInvalid");
    return err instanceof Error ? err.message : t("common.error");
  }

  function passwordError(err: unknown) {
    const raw = err instanceof Error ? err.message.toLowerCase() : "";
    if (raw.includes("rate") || raw.includes("security purposes")) return t("auth.tooMany");
    if (raw.includes("invalid login credentials") || raw.includes("invalid credentials"))
      return t("auth.wrongPassword");
    return err instanceof Error ? err.message : t("common.error");
  }


  async function resendCode() {
    if (cooldown > 0) return;
    setBusy(true);
    try {
      if (otpType === "signup") {
        const { error } = await supabase.auth.resend({ type: "signup", email });
        if (error) throw error;
      } else {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: `${authRedirectOrigin()}/reset-password`,
        });
        if (error) throw error;
      }
      setCooldown(60);
      toast.success(t("auth.codeSent"));
    } catch (err) {
      toast.error(otpError(err));
    } finally {
      setBusy(false);
    }
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      if (mode === "otp") {
        try {
          const { error } = await supabase.auth.verifyOtp({
            email,
            token: otp.trim(),
            type: otpType,
          });
          if (error) throw error;
        } catch (err) {
          toast.error(otpError(err));
          return;
        }
        if (otpType === "recovery") {
          await router.navigate({ to: "/reset-password" });
        } else {
          toast.success(t("auth.verified"));
          setLeaving(true);
          window.setTimeout(() => void router.navigate({ to: "/" }), 700);
        }
        return;
      }

      if (mode === "forgot") {
        try {
          const { error } = await supabase.auth.resetPasswordForEmail(email, {
            redirectTo: `${authRedirectOrigin()}/reset-password`,
          });
          if (error) throw error;
        } catch (err) {
          toast.error(otpError(err));
          return;
        }
        setCooldown(60);
        toast.success(t("auth.resetSent"));
        setOtpType("recovery");
        setOtp("");
        setMode("otp");
        return;
      }

      const check = await guard({ data: { deviceId: deviceId() } });
      if (!check.allowed) {
        toast.error(t("auth.blocked"));
        return;
      }

      if (mode === "up") {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: authRedirectOrigin(),
            data: { full_name: name || email.split("@")[0] },
          },
        });
        if (error) throw error;
        setCooldown(60);
        toast.success(t("auth.verifySent"));
        setOtpType("signup");
        setOtp("");
        setMode("otp");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        setLeaving(true);
        window.setTimeout(() => void router.navigate({ to: "/" }), 700);
      }
    } catch (err) {
      toast.error(passwordError(err));
    } finally {
      setBusy(false);
    }
  }



  if (leaving) return <AuthTransition mode="in" label={t("auth.welcome")} />;

  return (
    <div className="surface-hero flex min-h-[calc(100vh-4rem)] items-center justify-center px-4 py-12">
      <div className="w-full max-w-md animate-fade-up rounded-2xl border border-border/70 bg-card/90 p-6 card-elevated backdrop-blur sm:p-8">
        <span className="grid size-11 place-items-center rounded-xl bg-primary text-primary-foreground shadow-gold">
          <Gamepad2 className="size-5" />
        </span>
        <h1 className="mt-4 font-display text-2xl font-bold">
          {mode === "up"
            ? t("auth.signUp")
            : mode === "forgot"
              ? t("auth.reset")
              : mode === "otp"
                ? t("auth.verify")
                : t("auth.signIn")}
        </h1>

        <form onSubmit={submit} className="mt-6 space-y-4">
          {mode === "otp" ? (
            <>
              <p className="text-sm text-muted-foreground">{t("auth.codeHint")}</p>
              <div className="space-y-2">
                <Label htmlFor="otp">{t("auth.code")}</Label>
                <Input
                  id="otp"
                  inputMode="numeric"
                  autoComplete="one-time-code"
                  required
                  minLength={6}
                  maxLength={6}
                  pattern="[0-9]{6}"
                  placeholder="••••••"
                  className="text-center text-2xl font-bold tracking-[0.5em]"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value.replace(/\D/g, "").slice(0, 6))}
                />
              </div>
            </>
          ) : null}
          {mode === "up" ? (
            <div className="space-y-2">
              <Label htmlFor="name">{t("auth.name")}</Label>
              <Input id="name" value={name} onChange={(e) => setName(e.target.value)} maxLength={60} />
            </div>
          ) : null}

          {mode !== "otp" ? (
            <div className="space-y-2">
              <Label htmlFor="email">{t("auth.email")}</Label>
              <Input
                id="email"
                type="email"
                required
                maxLength={255}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
          ) : null}

          {mode !== "forgot" && mode !== "otp" ? (
            <div className="space-y-2">
              <Label htmlFor="password">{t("auth.password")}</Label>
              <Input
                id="password"
                type="password"
                required
                minLength={6}
                maxLength={72}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
          ) : null}

          <Button type="submit" className="w-full shadow-gold" disabled={busy}>
            {busy ? <Loader2 className="mr-2 size-4 animate-spin" /> : null}
            {mode === "up"
              ? t("auth.signUp")
              : mode === "forgot"
                ? t("auth.reset")
                : mode === "otp"
                  ? t("auth.verify")
                  : t("auth.signIn")}
          </Button>
        </form>


        <div className="mt-6 space-y-2 text-center text-sm text-muted-foreground">
          {mode === "otp" ? (
            <>
              <button
                type="button"
                className="hover:text-accent disabled:opacity-50"
                onClick={resendCode}
                disabled={busy || cooldown > 0}
              >
                {cooldown > 0 ? `${t("auth.resend")} (${cooldown})` : t("auth.resend")}
              </button>
              <p>
                <button type="button" className="font-semibold text-accent" onClick={() => setMode("in")}>
                  {t("auth.signIn")}
                </button>
              </p>
            </>
          ) : mode === "in" ? (
            <>
              <button className="hover:text-accent" onClick={() => setMode("forgot")}>
                {t("auth.forgot")}
              </button>
              <p>
                {t("auth.noAccount")}{" "}
                <button className="font-semibold text-accent" onClick={() => setMode("up")}>
                  {t("auth.signUp")}
                </button>
              </p>
            </>
          ) : (
            <p>
              {t("auth.haveAccount")}{" "}
              <button className="font-semibold text-accent" onClick={() => setMode("in")}>
                {t("auth.signIn")}
              </button>
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
