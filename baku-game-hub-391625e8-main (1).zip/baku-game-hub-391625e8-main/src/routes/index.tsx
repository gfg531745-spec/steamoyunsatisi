import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Search, Sparkles, ShieldCheck, Zap } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { GameCard } from "@/components/GameCard";
import { NoticeDialog } from "@/components/NoticeDialog";
import { useCart, useGames } from "@/hooks/useCart";
import { useSession } from "@/hooks/useAuth";
import { useI18n } from "@/i18n";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { matchesGame } from "@/lib/gameSearch";


export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "BakuSteamShop — Kompüter oyunları cəmi 4 ₼" },
      {
        name: "description",
        content:
          "GTA 5, Cyberpunk 2077, EA FC və 90+ populyar PC oyunu cəmi 4 ₼-dən. Ani çatdırılma, WhatsApp dəstəyi, Azərbaycan mağazası.",
      },
      { property: "og:title", content: "BakuSteamShop — PC oyunları 4 ₼" },
      {
        property: "og:description",
        content: "90+ populyar kompüter oyunu cəmi 4 ₼. Ani çatdırılma və WhatsApp dəstəyi.",
      },
    ],
  }),
  component: Index,
});

function Index() {
  const { t } = useI18n();
  const [q, setQ] = useState("");
  const { data: games, isLoading } = useGames();
  const cart = useCart();
  const { data: session } = useSession();
  const navigate = useNavigate();

  const owned = useQuery({
    queryKey: ["my-games", session?.user.id],
    enabled: Boolean(session),
    queryFn: async () => {
      const { data } = await supabase.from("user_games").select("game_id");
      return new Set((data ?? []).map((r) => r.game_id));
    },
  });

  const filtered = useMemo(() => {
    const list = games ?? [];
    const needle = q.trim();
    if (!needle) return list;
    return list.filter((g) => matchesGame(g.title, needle));
  }, [games, q]);


  return (
    <>
      <NoticeDialog />

      <section className="surface-hero relative overflow-hidden border-b border-border/60">
        <div className="pointer-events-none absolute inset-0 grid-overlay" />
        <div className="pointer-events-none absolute -left-24 top-10 size-72 rounded-full bg-accent/25 blur-3xl animate-glow" />
        <div className="pointer-events-none absolute -right-16 bottom-0 size-80 rounded-full bg-primary/25 blur-3xl animate-glow" />
        <div className="pointer-events-none absolute left-1/2 top-0 h-px w-3/4 -translate-x-1/2 bg-gradient-to-r from-transparent via-accent/60 to-transparent" />
        <div className="relative mx-auto w-full max-w-7xl px-4 py-16 sm:py-24">
          <span className="inline-flex animate-fade-in items-center gap-2 rounded-full border border-accent/40 bg-background/50 px-3 py-1 text-xs font-medium text-accent backdrop-blur">
            <Sparkles className="size-3.5" />
            {t("home.badge")}
          </span>
          <h1 className="mt-5 max-w-3xl animate-fade-up text-4xl font-black leading-[1.05] sm:text-6xl">
            <span className="text-gold">{t("home.title")}</span>
          </h1>
          <p className="mt-4 max-w-xl animate-fade-up text-base text-muted-foreground sm:text-lg">
            {t("home.subtitle")}
          </p>
          <div className="mt-8 flex animate-fade-up flex-wrap gap-3">
            <Button asChild size="lg" className="shadow-gold">
              <a href="#games">{t("home.browse")}</a>
            </Button>
            <Button asChild size="lg" variant="outline">
              <Link to="/packages">{t("nav.packages")}</Link>
            </Button>
          </div>

          <div className="mt-10 grid max-w-3xl animate-fade-up grid-cols-1 gap-3 sm:grid-cols-3">
            {[
              { icon: Zap, label: "4 ₼", sub: t("home.gamesCount") },
              { icon: ShieldCheck, label: "WhatsApp", sub: "+994 55 584 20 12" },
              { icon: Sparkles, label: "XP & Level", sub: "3 · 5 · 10 · 15 · 20 · 25" },
            ].map((s) => (
              <div
                key={s.label}
                className="flex items-center gap-3 rounded-xl border border-border/70 bg-card/70 p-3 backdrop-blur"
              >
                <span className="grid size-9 place-items-center rounded-lg bg-accent/15 text-accent">
                  <s.icon className="size-4" />
                </span>
                <div className="min-w-0">
                  <p className="truncate font-display text-sm font-bold">{s.label}</p>
                  <p className="truncate text-xs text-muted-foreground">{s.sub}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="games" className="mx-auto w-full max-w-7xl px-4 py-12">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h2 className="font-display text-2xl font-bold sm:text-3xl">{t("home.allGames")}</h2>
            <p className="text-sm text-muted-foreground">
              {(games ?? []).length} {t("home.gamesCount")}
            </p>
          </div>
          <div className="relative w-full sm:w-80">
            <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder={t("home.search")}
              className="pl-9"
            />
          </div>
        </div>

        {isLoading ? (
          <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
            {Array.from({ length: 10 }).map((_, i) => (
              <div key={i} className="aspect-[2/3] rounded-2xl bg-card shimmer-line" />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <p className="mt-12 text-center text-muted-foreground">{t("home.noResults")}</p>
        ) : (
          <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
            {filtered.map((game, i) => (
              <GameCard
                key={game.id}
                game={game}
                index={i}
                inCart={cart.has(game.id)}
                owned={owned.data?.has(game.id)}
                onAdd={() => {
                  if (!session) {
                    toast.error(t("cart.needAuth"));
                    void navigate({ to: "/auth" });
                    return;
                  }
                  cart.add(game.id);
                }}
              />
            ))}
          </div>
        )}
      </section>
    </>
  );
}
