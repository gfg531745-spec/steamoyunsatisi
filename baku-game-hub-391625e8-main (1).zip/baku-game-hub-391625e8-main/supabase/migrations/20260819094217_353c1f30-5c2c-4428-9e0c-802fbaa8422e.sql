CREATE TYPE public.app_role AS ENUM ('admin','user');

CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text,
  display_name text,
  xp integer NOT NULL DEFAULT 0,
  level integer NOT NULL DEFAULT 1,
  gift_credits integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

CREATE POLICY "profiles_select_own" ON public.profiles FOR SELECT TO authenticated
  USING (auth.uid() = id OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "profiles_update_own" ON public.profiles FOR UPDATE TO authenticated
  USING (auth.uid() = id) WITH CHECK (auth.uid() = id);
CREATE POLICY "profiles_insert_own" ON public.profiles FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = id);

CREATE POLICY "roles_select" ON public.user_roles FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_role(auth.uid(),'admin'));

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, email, display_name)
  VALUES (NEW.id, NEW.email, COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email,'@',1)))
  ON CONFLICT (id) DO NOTHING;
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id,'user') ON CONFLICT DO NOTHING;
  IF lower(NEW.email) = 'gfg531745@gmail.com' THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id,'admin') ON CONFLICT DO NOTHING;
  END IF;
  RETURN NEW;
END;
$$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

CREATE TABLE public.games (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  slug text NOT NULL UNIQUE,
  cover_url text,
  steam_appid integer,
  price numeric(10,2) NOT NULL DEFAULT 4.00,
  active boolean NOT NULL DEFAULT true,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.games TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.games TO authenticated;
GRANT ALL ON public.games TO service_role;
ALTER TABLE public.games ENABLE ROW LEVEL SECURITY;
CREATE POLICY "games_public_read" ON public.games FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "games_admin_write" ON public.games FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

CREATE TABLE public.game_credentials (
  game_id uuid PRIMARY KEY REFERENCES public.games(id) ON DELETE CASCADE,
  account_email text,
  account_password text,
  note text,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.game_credentials TO authenticated;
GRANT ALL ON public.game_credentials TO service_role;
ALTER TABLE public.game_credentials ENABLE ROW LEVEL SECURITY;
CREATE POLICY "creds_admin_all" ON public.game_credentials FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

CREATE TABLE public.cart_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  game_id uuid NOT NULL REFERENCES public.games(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, game_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cart_items TO authenticated;
GRANT ALL ON public.cart_items TO service_role;
ALTER TABLE public.cart_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "cart_own" ON public.cart_items FOR ALL TO authenticated
  USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

CREATE TABLE public.packages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  price numeric(10,2) NOT NULL,
  games_count integer NOT NULL DEFAULT 1,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.packages TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.packages TO authenticated;
GRANT ALL ON public.packages TO service_role;
ALTER TABLE public.packages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "packages_public_read" ON public.packages FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "packages_admin_write" ON public.packages FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

CREATE TABLE public.orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'pending',
  kind text NOT NULL DEFAULT 'games',
  package_id uuid REFERENCES public.packages(id) ON DELETE SET NULL,
  total numeric(10,2) NOT NULL DEFAULT 0,
  contact text,
  created_at timestamptz NOT NULL DEFAULT now(),
  confirmed_at timestamptz
);
GRANT SELECT, INSERT, UPDATE ON public.orders TO authenticated;
GRANT ALL ON public.orders TO service_role;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
CREATE POLICY "orders_own_read" ON public.orders FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "orders_own_insert" ON public.orders FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());
CREATE POLICY "orders_admin_update" ON public.orders FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

CREATE TABLE public.order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  game_id uuid REFERENCES public.games(id) ON DELETE SET NULL,
  title text NOT NULL,
  price numeric(10,2) NOT NULL DEFAULT 0
);
GRANT SELECT, INSERT ON public.order_items TO authenticated;
GRANT ALL ON public.order_items TO service_role;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "order_items_read" ON public.order_items FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.orders o WHERE o.id = order_id AND (o.user_id = auth.uid() OR public.has_role(auth.uid(),'admin'))));
CREATE POLICY "order_items_insert" ON public.order_items FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM public.orders o WHERE o.id = order_id AND o.user_id = auth.uid()));

CREATE TABLE public.user_games (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  game_id uuid NOT NULL REFERENCES public.games(id) ON DELETE CASCADE,
  source text NOT NULL DEFAULT 'order',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, game_id)
);
GRANT SELECT ON public.user_games TO authenticated;
GRANT ALL ON public.user_games TO service_role;
ALTER TABLE public.user_games ENABLE ROW LEVEL SECURITY;
CREATE POLICY "user_games_read" ON public.user_games FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_role(auth.uid(),'admin'));

CREATE TABLE public.login_attempts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ip text NOT NULL,
  device_id text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX login_attempts_ip_idx ON public.login_attempts (ip, created_at DESC);
GRANT ALL ON public.login_attempts TO service_role;
ALTER TABLE public.login_attempts ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.ip_blocks (
  ip text PRIMARY KEY,
  blocked_until timestamptz NOT NULL,
  reason text
);
GRANT ALL ON public.ip_blocks TO service_role;
ALTER TABLE public.ip_blocks ENABLE ROW LEVEL SECURITY;

INSERT INTO public.games (title, slug, steam_appid, sort_order) VALUES
('Ghost of Tsushima DIRECTOR''S CUT','ghost-of-tsushima-director-s-cut',2215430,0),('FIVE NIGHTS AT FREDDY''S: HELP WANTED','five-nights-at-freddy-s-help-wanted',732690,1),('Mortal Kombat 11','mortal-kombat-11',976310,2),('City Car Driving','city-car-driving',493490,3),('DARK SOULS II: Scholar of the First Sin','dark-souls-ii-scholar-of-the-first-sin',335300,4),('METAL GEAR SOLID 3 Δ: SNAKE EATER + Digital Deluxe Edition','metal-gear-solid-3-snake-eater-digital-deluxe-edition',2417610,5),('Please, Don''t Touch Anything 3D','please-don-t-touch-anything-3d',529590,6),('Poppy Playtime + Chapter 1-2-3-4-5','poppy-playtime-chapter-1-2-3-4-5',1721470,7),('Raft','raft',648800,8),('FC 25','fc-25',2669320,9),('Counter-Strike 1.6','counter-strike-1-6',10,10),('Party Panic','party-panic',506500,11),('Lies of P + Overture DLC','lies-of-p-overture-dlc',1627720,12),('CRISIS CORE –FINAL FANTASY VII– REUNION','crisis-core-final-fantasy-vii-reunion',1608070,13),('Only Up!','only-up',2465350,14),('Cyberpunk 2077','cyberpunk-2077',1091500,15),('Mafia: The Old Country + Deluxe Edition','mafia-the-old-country-deluxe-edition',1941540,16),('UNCHARTED: Legacy of Thieves Collection','uncharted-legacy-of-thieves-collection',1659420,17),('Grand Theft Auto V Legacy','grand-theft-auto-v-legacy',271590,18),('Grand Theft Auto V Enhanced','grand-theft-auto-v-enhanced',3240220,19),('Max Payne 1','max-payne-1',12140,20),('ARK: Survival Evolved','ark-survival-evolved',346110,21),('Resident Evil 4 Remake','resident-evil-4-remake',2050650,22),('Black Myth: Wukong','black-myth-wukong',2358720,23),('Counter-Strike: Condition Zero','counter-strike-condition-zero',80,24),('Kindergarten','kindergarten',589590,25),('Football Life Simulator','football-life-simulator',3158270,26),('Mafia: Definitive Edition','mafia-definitive-edition',1030840,27),('Sekiro: Shadows Die Twice','sekiro-shadows-die-twice',814380,28),('WWE 2K19','wwe-2k19',842100,29),('SUPERHOT','superhot',322500,30),('Red Dead Redemption 2','red-dead-redemption-2',1174180,31),('Marvel''s Spider-Man Remastered','marvel-s-spider-man-remastered',1817070,32),('Grand Theft Auto: San Andreas','grand-theft-auto-san-andreas',12120,33),('FIFA 23 + Ultimate Edition','fifa-23-ultimate-edition',1811260,34),('Five Nights at Freddy''s: Security Breach','five-nights-at-freddy-s-security-breach',747660,35),('Internet Cafe Simulator 2','internet-cafe-simulator-2',1563180,36),('SILENT HILL f - Digital Deluxe Edition','silent-hill-f-digital-deluxe-edition',2947440,37),('Lossless Scaling','lossless-scaling',993090,38),('Left 4 Dead','left-4-dead',500,39),('Escape the Backrooms','escape-the-backrooms',1943950,40),('Pro Evolution Soccer 2014','pro-evolution-soccer-2014',233310,41),('Supermarket Simulator','supermarket-simulator',2670630,42),('Plague Inc: Evolved','plague-inc-evolved',246620,43),('Plants vs. Zombies: Game of the Year','plants-vs-zombies-game-of-the-year',3590,44),('Hello Neighbor','hello-neighbor',521890,45),('Mafia II: Definitive Edition','mafia-ii-definitive-edition',1030830,46),('Dispatch + Digital Deluxe Edition','dispatch-digital-deluxe-edition',2592160,47),('Grand Theft Auto: San Andreas - The Definitive Edition','grand-theft-auto-san-andreas-the-definitive-edition',1547000,48),('Wallpaper Engine','wallpaper-engine',431960,49),('Call of Duty: Modern Warfare 3 (2011)','call-of-duty-modern-warfare-3-2011',115300,50),('The Last of Us Part II Remastered','the-last-of-us-part-ii-remastered',2531310,51),('SUPERHOT: MIND CONTROL DELETE','superhot-mind-control-delete',690040,52),('God of War','god-of-war',1593500,53),('FC 24','fc-24',2195250,54),('Five Nights at Freddy''s 4','five-nights-at-freddy-s-4',388090,55),('Outlast','outlast',238320,56),('ELDEN RING + Shadow of the Erdtree DLC','elden-ring-shadow-of-the-erdtree-dlc',1245620,57),('Forza Horizon 5','forza-horizon-5',1551360,58),('Goat Simulator 3','goat-simulator-3',850190,59),('Grand Theft Auto: Vice City','grand-theft-auto-vice-city',12110,60),('FreshWomen - Season 1','freshwomen-season-1',1350650,61),('Grand Theft Auto IV: The Complete Edition','grand-theft-auto-iv-the-complete-edition',12210,62),('Nioh 3 + Digital Deluxe Edition','nioh-3-digital-deluxe-edition',3681010,63),('FIFA 22 + Ultimate Edition','fifa-22-ultimate-edition',1506830,64),('A Plague Tale: Requiem','a-plague-tale-requiem',1182900,65),('DOOM: The Dark Ages','doom-the-dark-ages',3017860,66),('Clair Obscur: Expedition 33 + Deluxe Edition','clair-obscur-expedition-33-deluxe-edition',1903340,67),('Euro Truck Simulator 2','euro-truck-simulator-2',227300,68),('Garry''s Mod','garry-s-mod',4000,69),('The Amazing Spider-Man 2','the-amazing-spider-man-2',267550,70),('Resident Evil 7 Biohazard','resident-evil-7-biohazard',418370,71),('Kindergarten 2','kindergarten-2',1067850,72),('Call of Duty 4: Modern Warfare (2007)','call-of-duty-4-modern-warfare-2007',7940,73),('Counter-Strike: Condition Zero Deleted Scenes','counter-strike-condition-zero-deleted-scenes',100,74),('Mount & Blade II Bannerlord','mount-blade-ii-bannerlord',261550,75),('Left 4 Dead 2','left-4-dead-2',550,76),('Red Dead Redemption 1','red-dead-redemption-1',2668510,77),('METAL GEAR SOLID V: THE PHANTOM PAIN','metal-gear-solid-v-the-phantom-pain',287700,78),('eFootball PES 2021 SEASON UPDATE','efootball-pes-2021-season-update',1259970,79),('Max Payne 2','max-payne-2',12150,80),('DARK SOULS: REMASTERED','dark-souls-remastered',570940,81),('ELDEN RING + DELUXE EDITION','elden-ring-deluxe-edition',1245620,82),('Half-Life','half-life',70,83),('Call of Duty: Modern Warfare 2 (2009)','call-of-duty-modern-warfare-2-2009',10180,84),('Pacify','pacify',967050,85),('Five Nights at Freddy''s: Into the Pit','five-nights-at-freddy-s-into-the-pit',2638370,86),('God of War Ragnarök','god-of-war-ragnarok',2322010,87),('FC 26 - EA Hesabı','fc-26-ea-hesab',3405690,88),('Streamer Life Simulator 2','streamer-life-simulator-2',2890830,89),('Five Nights at Freddy''s: Help Wanted 2','five-nights-at-freddy-s-help-wanted-2',2287520,90),('DARK SOULS III','dark-souls-iii',374320,91),('Forza Horizon 4','forza-horizon-4',1293830,92),('The Witcher 3: Wild Hunt','the-witcher-3-wild-hunt',292030,93),('FC 26 + Ultimate Edition + Türkçe Spiker','fc-26-ultimate-edition-turkce-spiker',3405690,94)
ON CONFLICT (slug) DO NOTHING;

UPDATE public.games SET cover_url = 'https://cdn.cloudflare.steamstatic.com/steam/apps/2465350/header.jpg' WHERE slug = 'only-up';
UPDATE public.games SET cover_url = 'https://cdn.cloudflare.steamstatic.com/steam/apps/388090/header.jpg' WHERE slug = 'five-nights-at-freddy-s-4';
UPDATE public.games SET cover_url = 'https://cdn.cloudflare.steamstatic.com/steam/apps/267550/header.jpg' WHERE slug = 'the-amazing-spider-man-2';
UPDATE public.games SET cover_url = 'https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/3681010/a21264e9fd476dcb2901c2432b598107d024c5a8/header.jpg' WHERE slug = 'nioh-3-digital-deluxe-edition';
UPDATE public.games SET cover_url = 'https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/3405690/2d96aa1b06e453cd62dae9029d412f19e61932c3/header.jpg' WHERE slug IN ('fc-26-ea-hesab','fc-26-ultimate-edition-turkce-spiker');

INSERT INTO public.packages (title, description, price, games_count) VALUES
('3 Oyun Paketi','İstədiyiniz 3 oyunu seçin', 10.00, 3),
('5 Oyun Paketi','İstədiyiniz 5 oyunu seçin', 16.00, 5);