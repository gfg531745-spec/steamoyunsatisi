CREATE TABLE IF NOT EXISTS public.coupons (
  code text PRIMARY KEY,
  percent integer NOT NULL CHECK (percent > 0 AND percent <= 100),
  max_uses integer NOT NULL CHECK (max_uses >= 0),
  used_count integer NOT NULL DEFAULT 0,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT ALL ON public.coupons TO service_role;
ALTER TABLE public.coupons ENABLE ROW LEVEL SECURITY;

INSERT INTO public.coupons (code, percent, max_uses)
VALUES ('CONGRULATONS', 50, 3)
ON CONFLICT (code) DO NOTHING;

ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS coupon_code text;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS discount numeric NOT NULL DEFAULT 0;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS original_total numeric;

CREATE OR REPLACE FUNCTION public.consume_coupon(_code text)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _percent integer;
BEGIN
  UPDATE public.coupons
     SET used_count = used_count + 1
   WHERE code = _code
     AND active
     AND used_count < max_uses
  RETURNING percent INTO _percent;
  RETURN _percent;
END;
$$;

CREATE OR REPLACE FUNCTION public.release_coupon(_code text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.coupons
     SET used_count = greatest(used_count - 1, 0)
   WHERE code = _code;
END;
$$;

CREATE OR REPLACE FUNCTION public.coupon_status(_code text)
RETURNS TABLE (percent integer, remaining integer)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT c.percent, greatest(c.max_uses - c.used_count, 0)
  FROM public.coupons c
  WHERE c.code = _code AND c.active;
$$;

REVOKE ALL ON FUNCTION public.consume_coupon(text) FROM public, anon, authenticated;
REVOKE ALL ON FUNCTION public.release_coupon(text) FROM public, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.consume_coupon(text) TO service_role;
GRANT EXECUTE ON FUNCTION public.release_coupon(text) TO service_role;
GRANT EXECUTE ON FUNCTION public.coupon_status(text) TO authenticated, service_role;