REVOKE ALL ON FUNCTION public.coupon_status(text) FROM public;
REVOKE ALL ON FUNCTION public.coupon_status(text) FROM anon;
REVOKE ALL ON FUNCTION public.coupon_status(text) FROM authenticated;
GRANT EXECUTE ON FUNCTION public.coupon_status(text) TO service_role;

REVOKE ALL ON FUNCTION public.consume_coupon(text) FROM public;
REVOKE ALL ON FUNCTION public.release_coupon(text) FROM public;